//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit4.h"
#include "File1.h"
#include "File1.h"
#include "Unit1.h"
#include "FileEditor.h"
#include "Project1PCH1.h"
#include "Unit2.h"
#include "Unit3.h"
#include "Unit6.h"
#include "Unit7.h"
#include "Unit8.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm4 *Form4;
//---------------------------------------------------------------------------
__fastcall TForm4::TForm4(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm4::Button1Click(TObject *Sender)
{
char name[40], model[40], type[40],color[40],kind_of_fuel[40],type_of_body[40],KPP[40],type_of_drive[40],qaz[5000];
int year,number_of_seats,number_in_stock,number_door,id;
float engine, power,tank_volume,price;
 car c;
 AnsiString

 tmp=ComboBox1->Text;
 strcpy(name,tmp.c_str());

 tmp=Edit2->Text;
 strcpy(model,tmp.c_str());


 tmp=ComboBox3->Text;
 c.setyear(StrToInt(tmp));

 tmp=ComboBox4->Text;
 c.setengine(StrToFloat(tmp));

 tmp=Edit6->Text;
 c.setpower(StrToFloat(tmp));

 tmp=ComboBox5->Text;
 c.setnumber_of_seats(StrToInt(tmp));

 tmp=ComboBox6->Text;
 strcpy(color,tmp.c_str());

 tmp=ComboBox7->Text;
 strcpy(kind_of_fuel,tmp.c_str());

 tmp=Edit10->Text;
 c.settank_volume(StrToFloat(tmp));

 tmp=Edit16->Text;
 c.setprice(StrToFloat(tmp));

 tmp=ComboBox8->Text;
 strcpy(type_of_body,tmp.c_str());

 tmp=ComboBox9->Text;
 strcpy(KPP,tmp.c_str());

 tmp=ComboBox10->Text;
 strcpy(type_of_drive,tmp.c_str());

 tmp=ComboBox11->Text;
 c.setdoor(StrToInt(tmp));

  tmp=Edit12->Text;
 strcpy(qaz,tmp.c_str());

	 c.setname(name);
	 c.setmodel(model);
	 c.setcolor(color);
	 c.setkind_of_fuel(kind_of_fuel);
	 c.settype_of_body(type_of_body);
	 c.setKPP(KPP);
	 c.settype_of_drive(type_of_drive);
	 c.setqaz(qaz);
	 WriteToFileCar(c);
}
//---------------------------------------------------------------------------


void __fastcall TForm4::FormCreate(TObject *Sender)
{
for( int i=0; i<2; i++ )
	{
	StatusBar1->Panels->Add();
	StatusBar1->Panels->Items[i]->Width = StatusBar1->Parent->Width/3;
	}
  ComboBox1->Items->Add("BMW");
  ComboBox1->Items->Add("Audi");
  ComboBox1->Items->Add("Mersedez");
  ComboBox1->Items->Add("Alfa Romeo");
  ComboBox1->Items->Add("Volkswagen");
  ComboBox1->Items->Add("Toyota");
  ComboBox1->Items->Add("Nissan");
  ComboBox1->Items->Add("Opel");
  ComboBox1->Items->Add("Fiat");
  ComboBox1->Items->Add("Abarth");
  ComboBox1->Items->Add("Acura");
  ComboBox1->Items->Add("Alpine");
  ComboBox1->Items->Add("Adler");
  ComboBox1->Items->Add("Aero");
  ComboBox1->Items->Add("Alxam");
  ComboBox1->Items->Add("Altamarea");
  ComboBox1->Items->Add("AMC");
  ComboBox1->Items->Add("Anaig");
  ComboBox1->Items->Add("Armstrong siddeley");
  ComboBox1->Items->Add("Aro");
  ComboBox1->Items->Add("Artega");
  ComboBox1->Items->Add("Asia");
  ComboBox1->Items->Add("AsiaStar");
  ComboBox1->Items->Add("Aston Martin");
  ComboBox1->Items->Add("ATS Corsa");
  ComboBox1->Items->Add("Audi");
  ComboBox1->Items->Add("Austin");
  ComboBox1->Items->Add("Austin-Healey");
  ComboBox1->Items->Add("Autobianchi");
  ComboBox1->Items->Add("BAIC");
  ComboBox1->Items->Add("Baojun");
  ComboBox1->Items->Add("Baoya");
  ComboBox1->Items->Add("Barkas");
  ComboBox1->Items->Add("Baw");
  ComboBox1->Items->Add("Beijing");
  ComboBox1->Items->Add("Bently");
  ComboBox1->Items->Add("Bertone");
  ComboBox1->Items->Add("Bio Auto");
  ComboBox1->Items->Add("Blonell");
  ComboBox1->Items->Add("BMW");
  ComboBox1->Items->Add("BMW-Alpina");
  ComboBox1->Items->Add("Bollingrt");
  ComboBox1->Items->Add("Borgward");
  ComboBox1->Items->Add("Brilliance");
  ComboBox1->Items->Add("Bristol");
  ComboBox1->Items->Add("Buggati");
  ComboBox1->Items->Add("Buick");
  ComboBox1->Items->Add("BYD");
  ComboBox1->Items->Add("Byton");
  ComboBox1->Items->Add("Cadillac");
  ComboBox1->Items->Add("Caterham");
  ComboBox1->Items->Add("Chana");
  ComboBox1->Items->Add("Changan");
  ComboBox1->Items->Add("Changhe");
  ComboBox1->Items->Add("Chery");
  ComboBox1->Items->Add("Chevrolet");
  ComboBox1->Items->Add("Chrysler");
  ComboBox1->Items->Add("Citroen");
  ComboBox1->Items->Add("Cupra");
  ComboBox1->Items->Add("Dacia");
  ComboBox1->Items->Add("Dudi");
  ComboBox1->Items->Add("Daewoo");
  ComboBox1->Items->Add("DAF");
  ComboBox1->Items->Add("DAF/VDL");
  ComboBox1->Items->Add("Dagger");
  ComboBox1->Items->Add("Daihatsu");
  ComboBox1->Items->Add("Daimler");
  ComboBox1->Items->Add("Datsum");
  ComboBox1->Items->Add("De Lorean");
  ComboBox1->Items->Add("Dodge");
  ComboBox1->Items->Add("Dongfeng");
  ComboBox1->Items->Add("DS");
  ComboBox1->Items->Add("Eagle");
  ComboBox1->Items->Add("FAW");
  ComboBox1->Items->Add("Ferrari");
  ComboBox1->Items->Add("Fiat");
  ComboBox1->Items->Add("Fiat-Abarth");
  ComboBox1->Items->Add("Fisker");
  ComboBox1->Items->Add("Ford");
  ComboBox1->Items->Add("FUQI");
  ComboBox1->Items->Add("Gac");
  ComboBox1->Items->Add("Geely");
  ComboBox1->Items->Add("GMC");
  ComboBox1->Items->Add("Geo");
  ComboBox1->Items->Add("Gonow");
  ComboBox1->Items->Add("Great Wall");
  ComboBox1->Items->Add("Groz");
  ComboBox1->Items->Add("Hafei");
  ComboBox1->Items->Add("Hanomag");
  ComboBox1->Items->Add("Haval");
  ComboBox1->Items->Add("Honda");
  ComboBox1->Items->Add("Hyundai");
  ComboBox1->Items->Add("Kia");
  ComboBox1->Items->Add("Lexus");
  ComboBox1->Items->Add("Mazda");
  ComboBox1->Items->Add("Mercedes-Benz");
  ComboBox1->Items->Add("McLaren");
  ComboBox1->Items->Add("Mitsubishi");
  ComboBox1->Items->Add("Nissan");
  ComboBox1->Items->Add("Opel");
  ComboBox1->Items->Add("Plymouth");
  ComboBox1->Items->Add("Peugeot");
  ComboBox1->Items->Add("Pontiac");
  ComboBox1->Items->Add("Porsche");
  ComboBox1->Items->Add("Renault");
  ComboBox1->Items->Add("Rolls-Royce");
  ComboBox1->Items->Add("Saab");
  ComboBox1->Items->Add("Saipa");
  ComboBox1->Items->Add("Samand");
  ComboBox1->Items->Add("Saturn");
  ComboBox1->Items->Add("Scion");
  ComboBox1->Items->Add("SEAT");
  ComboBox1->Items->Add("Skoda");
  ComboBox1->Items->Add("Smart");
  ComboBox1->Items->Add("SsangYong");
  ComboBox1->Items->Add("Subaru");
  ComboBox1->Items->Add("Suzuki");
  ComboBox1->Items->Add("TATA");
  ComboBox1->Items->Add("Tesla");
  ComboBox1->Items->Add("Tiger");
  ComboBox1->Items->Add("Toyota");
  ComboBox1->Items->Add("Trabant");
  ComboBox1->Items->Add("Triumph");
  ComboBox1->Items->Add("TVR");
  ComboBox1->Items->Add("Van Hool");
  ComboBox1->Items->Add("Vauxhall");
  ComboBox1->Items->Add("Venucia");
  ComboBox1->Items->Add("Volkswagen");
  ComboBox1->Items->Add("Volvo");
  ComboBox1->Items->Add("Wanderer");
  ComboBox1->Items->Add("Wartburg");
  ComboBox1->Items->Add("Weltmeister");
  ComboBox1->Items->Add("Willys");
  ComboBox1->Items->Add("Wuling");
  ComboBox1->Items->Add("Xin kai");
  ComboBox1->Items->Add("Xpeng");
  ComboBox1->Items->Add("Zastava");
  ComboBox1->Items->Add("Zotye");
  ComboBox1->Items->Add("Zuk");
  ComboBox1->Items->Add("ZX");
  ComboBox1->Items->Add("������");
  ComboBox1->Items->Add("���");
  ComboBox1->Items->Add("���");
  ComboBox1->Items->Add("���");
  ComboBox1->Items->Add("���");
  ComboBox1->Items->Add("���");
  ComboBox3->Items->Add("1980");
  ComboBox3->Items->Add("1981");
  ComboBox3->Items->Add("1982");
  ComboBox3->Items->Add("1983");
  ComboBox3->Items->Add("1984");
  ComboBox3->Items->Add("1985");
  ComboBox3->Items->Add("1986");
  ComboBox3->Items->Add("1987");
  ComboBox3->Items->Add("1988");
  ComboBox3->Items->Add("1989");
  ComboBox3->Items->Add("1990");
  ComboBox3->Items->Add("1991");
  ComboBox3->Items->Add("1992");
  ComboBox3->Items->Add("1993");
  ComboBox3->Items->Add("1994");
  ComboBox3->Items->Add("1995");
  ComboBox3->Items->Add("1996");
  ComboBox3->Items->Add("1997");
  ComboBox3->Items->Add("1998");
  ComboBox3->Items->Add("1999");
  ComboBox3->Items->Add("2000");
  ComboBox3->Items->Add("2001");
  ComboBox3->Items->Add("2002");
  ComboBox3->Items->Add("2003");
  ComboBox3->Items->Add("2004");
  ComboBox3->Items->Add("2005");
  ComboBox3->Items->Add("2006");
  ComboBox3->Items->Add("2007");
  ComboBox3->Items->Add("2008");
  ComboBox3->Items->Add("2009");
  ComboBox3->Items->Add("2010");
  ComboBox3->Items->Add("2011");
  ComboBox3->Items->Add("2012");
  ComboBox3->Items->Add("2013");
  ComboBox3->Items->Add("2014");
  ComboBox3->Items->Add("2015");
  ComboBox3->Items->Add("2016");
  ComboBox3->Items->Add("2017");
  ComboBox3->Items->Add("2018");
  ComboBox3->Items->Add("2019");
  ComboBox3->Items->Add("2020");
  ComboBox3->Items->Add("2021");
  ComboBox3->Items->Add("2022");
  ComboBox4->Items->Add("600");
  ComboBox4->Items->Add("800");
  ComboBox4->Items->Add("1000");
  ComboBox4->Items->Add("1100");
  ComboBox4->Items->Add("1200");
  ComboBox4->Items->Add("1300");
  ComboBox4->Items->Add("1400");
  ComboBox4->Items->Add("1500");
  ComboBox4->Items->Add("1600");
  ComboBox4->Items->Add("1700");
  ComboBox4->Items->Add("1800");
  ComboBox4->Items->Add("1900");
  ComboBox4->Items->Add("2000");
  ComboBox4->Items->Add("2200");
  ComboBox4->Items->Add("2300");
  ComboBox4->Items->Add("2400");
  ComboBox4->Items->Add("2500");
  ComboBox4->Items->Add("2700");
  ComboBox4->Items->Add("2900");
  ComboBox4->Items->Add("3000");
  ComboBox4->Items->Add("3200");
  ComboBox4->Items->Add("3500");
  ComboBox4->Items->Add("4000");
  ComboBox4->Items->Add("4400");
  ComboBox4->Items->Add("5000");
  ComboBox4->Items->Add("5500");
  ComboBox4->Items->Add("6000");
  ComboBox4->Items->Add("6750");
  ComboBox5->Items->Add("2");
  ComboBox5->Items->Add("3");
  ComboBox5->Items->Add("4");
  ComboBox5->Items->Add("5");
  ComboBox5->Items->Add("6");
  ComboBox5->Items->Add("7");
  ComboBox5->Items->Add("8");
  ComboBox5->Items->Add("9");
  ComboBox6->Items->Add("�����");
  ComboBox6->Items->Add("������");
  ComboBox6->Items->Add("ѳ���");
  ComboBox6->Items->Add("�������");
  ComboBox6->Items->Add("��������");
  ComboBox6->Items->Add("�����");
  ComboBox6->Items->Add("�������");
  ComboBox6->Items->Add("����������");
  ComboBox6->Items->Add("�������");
  ComboBox6->Items->Add("��������");
  ComboBox6->Items->Add("Գ��������");
  ComboBox6->Items->Add("���������");
  ComboBox6->Items->Add("������");
  ComboBox6->Items->Add("���������");
  ComboBox7->Items->Add("������");
  ComboBox7->Items->Add("������");
  ComboBox7->Items->Add("���");
  ComboBox7->Items->Add("ó����");
  ComboBox7->Items->Add("�������");
  ComboBox8->Items->Add("������������/��������");
  ComboBox8->Items->Add("̳�����");
  ComboBox8->Items->Add("�������");
  ComboBox8->Items->Add("���������");
  ComboBox8->Items->Add("����");
  ComboBox8->Items->Add("�������� ������(�� 1.5 �)");
  ComboBox8->Items->Add("��������");
  ComboBox8->Items->Add("ϳ���");
  ComboBox9->Items->Add("��������");
  ComboBox9->Items->Add("�������");
  ComboBox9->Items->Add("���������");
  ComboBox9->Items->Add("�����");
  ComboBox9->Items->Add("�������");
  ComboBox10->Items->Add("������");
  ComboBox10->Items->Add("������");
  ComboBox10->Items->Add("��������");
  ComboBox11->Items->Add("2");
  ComboBox11->Items->Add("3");
  ComboBox11->Items->Add("4");
  ComboBox11->Items->Add("5");
  ComboBox11->Items->Add("5");
  ComboBox12->Items->Add("̳�� ����");
   ComboBox12->Items->Add("̳�� �����");
	ComboBox12->Items->Add("������");
	 ComboBox12->Items->Add("�������� � ��������");
	  ComboBox12->Items->Add("�������� �����");
	   ComboBox12->Items->Add("�������� ������");
		ComboBox12->Items->Add("�������� �����-�����");
		 ComboBox12->Items->Add("��������");
		  ComboBox12->Items->Add("���������");
		   ComboBox12->Items->Add("̳�� ������������ ���������");
		   ComboBox13->Items->Add("50");
		   ComboBox13->Items->Add("100");
		   ComboBox13->Items->Add("125");
		   ComboBox13->Items->Add("150");
		   ComboBox13->Items->Add("200");
		   ComboBox13->Items->Add("250");
		   ComboBox13->Items->Add("300");
		   ComboBox13->Items->Add("350");
		   ComboBox13->Items->Add("400");
		   ComboBox13->Items->Add("600");
		   ComboBox13->Items->Add("750");
		   ComboBox13->Items->Add("800");
		   ComboBox13->Items->Add("1000");
		   ComboBox13->Items->Add("1200");
		   ComboBox13->Items->Add("1500");
			 ComboBox14->Items->Add("1");
			   ComboBox14->Items->Add("2");
				 ComboBox14->Items->Add("3");



}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button2Click(TObject *Sender)
{
char name[40], model[40],color[40],kind_of_fuel[40],type_of_body[40],img[500];
int year,number_of_seats;
float engine, power,tank_volume,price;
 moto m;
 AnsiString
 tmp=ComboBox2->Text;
 strcpy(name,tmp.c_str());

 tmp=Edit2->Text;
 strcpy(model,tmp.c_str());

 tmp=ComboBox3->Text;
 m.setyear(StrToInt(tmp));

 tmp=ComboBox13->Text;
 m.setengine(StrToFloat(tmp));

 tmp=Edit6->Text;
 m.setpower(StrToFloat(tmp));

 tmp=ComboBox14->Text;
 m.setnumber_of_seats(StrToInt(tmp));

 tmp=ComboBox6->Text;
 strcpy(color,tmp.c_str());

 tmp=ComboBox7->Text;
 strcpy(kind_of_fuel,tmp.c_str());

 tmp=Edit10->Text;
 m.settank_volume(StrToFloat(tmp));

 tmp=Edit11->Text;
 m.setprice(StrToFloat(tmp));

 tmp=ComboBox12->Text;
 strcpy(type_of_body,tmp.c_str());

  tmp=Edit8->Text;
 strcpy(img,tmp.c_str());

	 m.setname(name);
	 m.setmodel(model);
	 m.setcolor(color);
	 m.setkind_of_fuel(kind_of_fuel);
	 m.settype_of_body(type_of_body);
	 m.setImg(img);
	 WriteToFileMoto(m);
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button3Click(TObject *Sender)
{
	if(OpenPictureDialog1->Execute())
	{
		Edit8->Text = OpenPictureDialog1->FileName;
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button4Click(TObject *Sender)
{
	if(OpenPictureDialog1->Execute())
	{
		Edit12->Text = OpenPictureDialog1->FileName;
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button5Click(TObject *Sender)
{
char name[40], model[40],color[40],kind_of_fuel[40],type_of_body[40],qwe[999];
int year,number_of_seats,number_door,number_window;
float engine, power,tank_volume,price;
 plane p;
 AnsiString
 tmp=Edit15->Text;
 strcpy(name,tmp.c_str());

 tmp=Edit2->Text;
 strcpy(model,tmp.c_str());

 tmp=ComboBox3->Text;
 p.setyear(StrToInt(tmp));

 tmp=ComboBox4->Text;
 p.setengine(StrToFloat(tmp));

 tmp=Edit6->Text;
 p.setpower(StrToFloat(tmp));

 tmp=ComboBox15->Text;
 p.setnumber_of_seats(StrToInt(tmp));

 tmp=ComboBox6->Text;
 strcpy(color,tmp.c_str());

 tmp=ComboBox7->Text;
 strcpy(kind_of_fuel,tmp.c_str());

 tmp=Edit10->Text;
 p.settank_volume(StrToFloat(tmp));

 tmp=Edit14->Text;
 p.setprice(StrToFloat(tmp));

  tmp=Edit9->Text;
 p.setnumber_door(StrToInt(tmp));

  tmp=Edit13->Text;
 p.setnumber_window(StrToInt(tmp));

  tmp=Edit1->Text;
 strcpy(qwe,tmp.c_str());

	 p.setname(name);
	 p.setmodel(model);
	 p.setcolor(color);
	 p.setkind_of_fuel(kind_of_fuel);
     p.setqwe(qwe);
	 WriteToFilePlane(p);
}
//---------------------------------------------------------------------------

void __fastcall TForm4::Button6Click(TObject *Sender)
{
	if(OpenPictureDialog1->Execute())
	{
		Edit1->Text = OpenPictureDialog1->FileName;
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm4::FormShow(TObject *Sender)
{
for (int i = 0; i < StatusBar1->Panels->Count; i++)
{
 StatusBar1->Panels->Items[0]->Text=Form1->Edit1->Text;
}
}
//---------------------------------------------------------------------------

void __fastcall TForm4::FormKeyUp(TObject *Sender, WORD &Key, TShiftState Shift)
{
switch (Key)
	{
	case VK_CAPITAL:
		StatusBar1->Panels->Items[1]->Text = (::GetKeyState(VK_CAPITAL)) ? "CapsLock" : "";
		break;
	case VK_NUMLOCK:
		StatusBar1->Panels->Items[2]->Text = (::GetKeyState(VK_NUMLOCK)) ? "NumLock" : "";
		break;
}
}
//---------------------------------------------------------------------------


