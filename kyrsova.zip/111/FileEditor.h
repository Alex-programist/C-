#include <iostream>
#include <fstream>
#pragma once
  using namespace std;
 template<typename Type>
class FileEditor
{
private:
	char filename[100];
public:
	FileEditor(const char* filename)
	{
		strcpy(this->filename, filename);
    }

	void WriteToFile(Type a)
    {
		ofstream f_out;
        f_out.open(filename, ios::binary | ios::app);
        if (f_out.is_open())
        {
			f_out.write((char*)&a, sizeof(a));
		}
        f_out.close();
    };

	int ReadFromFile(Type arr[100])
	{
        ifstream f_in;
        int i = 0;
        f_in.open(filename, ios::binary | ios::in);
        if (f_in.is_open())
        {
			Type a;
			while (f_in.read((char*)&a, sizeof(a)))
            {
				arr[i] = a;
                i++;
            }
        }
        f_in.close();
        return i;
	};
};

