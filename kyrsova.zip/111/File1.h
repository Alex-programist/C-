#ifndef  FILE1_H
#define  FILE1_H
#pragma once
#include <iostream>
#include "FileEditor.h"
using namespace std;
class user
{
protected:
char login[40];
char password[40];
char firstname[40];
char name[40];
char lastname[40];
char sex[40];
int age;
char phone[40];
public:
char* getlogin();
char* getpassword();
char* getfirstname();
char* getname();
char* getlastname();
char* getsex();
int getage();
char* getphone();
void setlogin(char*login);
void setpassword(char*pasword);
void setfirstname(char*firstname);
void setname(char*name);
void setlastname(char*lastname);
void setsex(char*sex);
void setage(int age);
void setphone(char*phone);
//void virtual ff()=0;
};

//------------------------------------------------------------
class saler:public user
{
char adress[40];
public:
char* getadress();
void setadress(char*adress);
//void ff() override;
};
//------------------------------------------------------------
class buyer:public user
{
char index_self[40];
public:
char* getindex_self();
void setindex_self(char*index_self);
//void ff() override;
};
extern buyer current_user;
//------------------------------------------------------------
class administrator:public user
{
char email[40];
public:
char* getEmail();
void setEmail(char* email);
//void ff() override;
};
//------------------------------------------------------------
class transport
{
protected:
	char name[40];
	char model[40];
	int year;
	float engine;
	float power;
	int number_of_seats;
	char color[40];
	char kind_of_fuel[40];
	float tank_volume;
	float price;
public:
	transport(){strcpy(name,"");}
	char* getname();
	char* getmodel();
	char* gettype();
	int getyear();
	float getengine();
	float getpower();
	int getnumber_of_seats();
	char* getcolor();
	int getnumber_in_stock();
	char* getkind_of_fuel();
	float gettank_volume();
	float getprice();
	void setname(char*name);
	void setmodel(char*model);
	void settype(char*type);
	void setyear(int year);
	void setengine(float engine);
	void setpower(float power);
	void setnumber_of_seats(int number_of_seats);
	void setcolor(char*color);
	void setnumber_in_stock(int number_in_stock);
	void setkind_of_fuel(char*kind_of_fuel);
	void settank_volume(float tank_volume);
	void setprice(float price);

//virtual int ChangeForm()=0;
};
//------------------------------------------------------------
class car:public transport
{
char type_of_body[40];
char KPP[40];
char type_of_drive[40];
int door;
char qaz[500];
public:
char*getqaz();
char*gettype_of_body();
char*getKPP();
char*gettype_of_drive();
int getdoor();
void setqaz(char*qaz);
void settype_of_body(char*type_of_body);
void setKPP(char*KPP);
void settype_of_drive(char*type_of_body);
void setdoor(int door);
};
//------------------------------------------------------------
class moto:public transport
{
char type_of_body[40];
char img[500];
public:
char*gettype_of_body();
char*getImg();
void settype_of_body(char*type_of_body);
void setImg(char*img);
};
//------------------------------------------------------------
class plane:public transport
{
int number_door;
int number_window;
char qwe[999];
public:
char* getqwe();
int getnumber_door();
int getnumber_window();
void setqwe(char*qwe);
void setnumber_door(int number_door);
void setnumber_window(int number_window);
};
//------------------------------------------------------------
class yacht:public transport
{
float height;
float width;
float lenght;
public:
float getheight();
float getwidth();
float getlenght();
void setheight(float height);
void setwidth(float width);
void setlenght(float lenght);
};
//------------------------------------------------------------
class reviews
{
private:
	char login[40];
	char text[40];
	char marks[40];
public:
	char*getlogin();
	char*gettext();
	char*getmarks();
	void setlogin(char*login);
	void settext(char*text);
	void setmarks(char*marks);
};

class order
{
private:
	moto obj;
	car obj_car;
	plane obj_plane;
	buyer obj_buyer;
	bool accepted;
public:
	car getobj_car();
	moto getmoto();
	plane getplane_obj();
	buyer getobj_buyer();
	bool getaccepted();
 void setmoto(moto obj);
 void setobj_buyer(buyer obj_buyer);
 void setplane(plane obj_plane);
 void setaccepted(bool accepted);
 void setobj_car(car obj_car);
};

void WriteToFileO(order o);
int ReadFromFileO(order arr[100]);
void RewriteFileO(order arr[100],int N);
const char FileO[]="order.dat";
//------------------------------------------------------------
const char FileBuyer[]="buyer.dat";
const char FileAdmin[]="admin.dat";
void WriteToFileBuyer(buyer a);
int ReadFromFileBuyer(buyer arr);

//------------------------------------------------------------
void WriteToFileReviews(reviews r);
int ReadFromFileReviews(reviews arr[1000]);
const char FileReviews[]="reviews.dat";
//------------------------------------------------------------
int SearchUser(char log[40] , char pass[30]);
bool SearchLogin(char log[40]);
//------------------------------------------------------------
void WriteToFileCar(car c);
int ReadFromFileCar(car arr[100]);
void RewriteFileCar(car arr[100],int N);
void DeleteCarsByName(char* name);
int SortYearCar(car arr[100]);
int SortYearqaz(car arr[100]);
const char FileCar[]="car.dat";
//------------------------------------------------------------
void WriteToFileMoto(moto m);
int ReadFromFileMoto(moto arr[100]);
void RewriteFileMoto(moto arr[100],int N);
void DeleteMotoByName(char* name);
int SortYearMoto(moto arr[100]);
int SortYearMotoUp(moto arr[100]);
const char FileMoto[]="moto.dat";
//------------------------------------------------------------
void WriteToFilePlane(plane p);
int ReadFromFilePlane(plane arr[100]);
void DeletePlaneByName(char* name);
int SortYearPlane(plane arr[100]);
int SortYearPlaneUp(plane arr[100]);
const char FilePlane[]="plane.dat";
void RewriteFilePlane(plane arr[100],int N);
#endif
