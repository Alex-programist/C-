//---------------------------------------------------------------------------

#ifndef Unit5H
#define Unit5H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ComCtrls.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Grids.hpp>
#include <Vcl.Imaging.pngimage.hpp>
#include <Vcl.Menus.hpp>
#include <VCLTee.Chart.hpp>
#include <VCLTee.Series.hpp>
#include <VclTee.TeeGDIPlus.hpp>
#include <VCLTee.TeEngine.hpp>
#include <VCLTee.TeeProcs.hpp>
#include <System.ImageList.hpp>
#include <Vcl.ImgList.hpp>
//---------------------------------------------------------------------------
class TForm5 : public TForm
{
__published:	// IDE-managed Components
	TImage *Image10;
	TImage *Image9;
	TImage *Image8;
	TImage *Image7;
	TImage *Image6;
	TImage *Image1;
	TLabel *Label1;
	TImage *Image2;
	TImage *Image3;
	TImage *Image4;
	TImage *Image5;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TLabel *Label6;
	TLabel *Label7;
	TStringGrid *StringGrid1;
	TStatusBar *StatusBar1;
	TButton *Button1;
	TMemo *Memo1;
	TEdit *Edit1;
	TEdit *Edit2;
	TChart *Chart1;
	TBarSeries *Series1;
	TButton *Button2;
	TButton *Button3;
	TButton *Button4;
	TMainMenu *MainMenu1;
	TMenuItem *N1;
	TMenuItem *N5;
	TMenuItem *N6;
	TMenuItem *N7;
	TMenuItem *N2;
	TMenuItem *N4;
	TMenuItem *N12;
	TMenuItem *N13;
	TMenuItem *N3;
	TMenuItem *Exel1;
	TMenuItem *N8;
	TMenuItem *N9;
	TMenuItem *Exel2;
	TImageList *ImageList1;
	void __fastcall FormShow(TObject *Sender);
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall Button4Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Memo1Click(TObject *Sender);
	void __fastcall Image1MouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall Image2MouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall Image3MouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall Image4MouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall Image5MouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall FormKeyUp(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall Image6Click(TObject *Sender);
	void __fastcall Image7Click(TObject *Sender);
	void __fastcall Image8Click(TObject *Sender);
	void __fastcall Image9Click(TObject *Sender);
	void __fastcall Image10Click(TObject *Sender);
	void __fastcall N2Click(TObject *Sender);
	void __fastcall N12Click(TObject *Sender);





private:	// User declarations
public:		// User declarations
	__fastcall TForm5(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm5 *Form5;
//---------------------------------------------------------------------------
#endif
