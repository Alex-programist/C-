//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit5.h"
#include "File1.h"
#include "File1.h"
#include "Project1PCH1.h"
#include "Unit1.h"
#include "Unit2.h"
#include "Unit3.h"
#include "Unit4.h"
#include<comobj.hpp>
#include "Unit6.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm5 *Form5;
//---------------------------------------------------------------------------
__fastcall TForm5::TForm5(TComponent* Owner)
	: TForm(Owner)
{
//---------------------------------------------------------------------------
}
int CntRecurrences(AnsiString substr,AnsiString str)
{
if (!substr.Length() || !str.Length() || !str.Pos(substr))
 {
  return 0;
 }
else
 {
  return (str.Length() - (StringReplace(str,substr,"",TReplaceFlags()<<rfReplaceAll)).Length())/substr.Length();
 }
}
//--------------------------------------------------------------------------
void FillStringGrid(int N, reviews arr[1000],TStringGrid* StringGrid1)
{
  for (int i=0; i < StringGrid1->RowCount; i++)
  for (int j=0; j<StringGrid1->ColCount;j++) StringGrid1->Cells[j][i]="";
  StringGrid1->RowCount=6;
  StringGrid1->Cells[0][0]="����";
  StringGrid1->Cells[1][0]="�����";
  StringGrid1->Cells[2][0]="������";
  for (int i = 0; i < N; i++)
  {
	StringGrid1->Cells[0][i+1]=arr[i].getlogin();
	StringGrid1->Cells[1][i+1]=arr[i].gettext();
	StringGrid1->Cells[2][i+1]=arr[i].getmarks();
	StringGrid1->RowCount++;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm5::FormShow(TObject *Sender)
{
for (int i = 0; i < StatusBar1->Panels->Count; i++)
{
 StatusBar1->Panels->Items[0]->Text=Form1->Edit1->Text;
}
reviews arr[1000];
 int N;
 N=ReadFromFileReviews(arr);
 FillStringGrid(N,arr,StringGrid1);
 Edit1->Text=Form1->Edit1->Text;

}
//---------------------------------------------------------------------------
void __fastcall TForm5::FormCreate(TObject *Sender)
{
for( int i=0; i<2; i++ )
	{
	StatusBar1->Panels->Add();
	StatusBar1->Panels->Items[i]->Width = StatusBar1->Parent->Width/3;
	}
}
//---------------------------------------------------------------------------
void __fastcall TForm5::Button1Click(TObject *Sender)
{
char log[40], text[40], marks[40];
  AnsiString tmp=Edit1->Text;
  strcpy(log,tmp.c_str());
  tmp=Memo1->Text;
  strcpy(text,tmp.c_str());
  tmp=Edit2->Text;
  strcpy(marks,tmp.c_str());
  reviews r;
  r.setlogin(log);
  r.settext(text);
  r.setmarks(marks);
  WriteToFileReviews(r);
  MessageBox(Handle,L"³���� ���������!",L"Auto.Cars",MB_OK| MB_ICONASTERISK) == IDOK;
  reviews arr[1000];
  int N;
  N=ReadFromFileReviews(arr);
  FillStringGrid(N,arr,StringGrid1);
}
//---------------------------------------------------------------------------
void __fastcall TForm5::Button4Click(TObject *Sender)
{
Chart1->Visible=false;
 Label2->Visible=false;
 Label3->Visible=false;
 Label4->Visible=false;
 Label5->Visible=false;
 Label6->Visible=false;
 Label7->Visible=false;
StringGrid1->Visible=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button3Click(TObject *Sender)
{
Variant app, books, book, sheet, Rang, vCell, vFont;
  app = CreateOleObject("Excel.Application");
  app.OlePropertySet("Visible",true);
  books = app.OlePropertyGet("Workbooks");
  books.OleProcedure("Add");
  book = books.OlePropertyGet("Item",1);
  sheet = book.OlePropertyGet("WorkSheets",1);
 String S;
  const int bounds[4] = {0, StringGrid1->RowCount, 0, StringGrid1->ColCount};
  Variant vData = VarArrayCreate(bounds, 3, varVariant);
  for(int i = 0; i < StringGrid1->RowCount; i++)
   for(int j = 0; j < StringGrid1->ColCount; j++)
	{
	  if((StringGrid1->Cells[j][i]).IsEmpty()) S = "";
	  else S = StringGrid1->Cells[j][i];
	  vData.PutElement(S, i, j);
	}
  Rang = sheet.OlePropertyGet("Range",sheet.OlePropertyGet("Cells",1,1),
		   sheet.OlePropertyGet("Cells",StringGrid1->RowCount,StringGrid1->ColCount));
  Rang.OlePropertySet("WrapText", false);
  Rang.OlePropertySet("Value",vData);
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Button2Click(TObject *Sender)
{
Label1->Caption="C��������� ������";
 Chart1->Visible=true;
 Label2->Visible=true;
 Label3->Visible=true;
 Label4->Visible=true;
 Label5->Visible=true;
 Label6->Visible=true;
 Label7->Visible=true;
 Series1->Clear();
 int one=0;
 int two=0;
 int free=0;
 int four=0;
 int five=0;
 for(int i = 1; i < StringGrid1->RowCount; i++)
  {
   if (StringGrid1->Cells[2][i]=="1") {
   one++;}
  else if (StringGrid1->Cells[2][i]=="2") {
   two++;
  }
  else if (StringGrid1->Cells[2][i]=="3") {
   free++;
  }
  else if (StringGrid1->Cells[2][i]=="4") {
   four++;
  }
  else if (StringGrid1->Cells[2][i]=="5") {
   five++;
  }
  }
  Series1->Add(one);
  Series1->Add(two);
  Series1->Add(free);
  Series1->Add(four);
  Series1->Add(five);
{
}
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Memo1Click(TObject *Sender)
{
Memo1->Text="";
}
//---------------------------------------------------------------------------


void __fastcall TForm5::Image1MouseMove(TObject *Sender, TShiftState Shift, int X,
          int Y)
{
Image1->Visible=false;
Image4->Visible=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Image2MouseMove(TObject *Sender, TShiftState Shift, int X,
          int Y)
{
Image1->Visible=false;
Image2->Visible=false;
Image6->Visible=true;
Image7->Visible=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Image3MouseMove(TObject *Sender, TShiftState Shift, int X,
          int Y)
{
  Image1->Visible=false;
Image2->Visible=false;
Image3->Visible=false;
Image6->Visible=true;
Image7->Visible=true;
Image8->Visible=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Image4MouseMove(TObject *Sender, TShiftState Shift, int X,
          int Y)
{
  Image1->Visible=false;
Image2->Visible=false;
Image3->Visible=false;
Image4->Visible=false;
Image6->Visible=true;
Image7->Visible=true;
Image8->Visible=true;
Image9->Visible=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Image5MouseMove(TObject *Sender, TShiftState Shift, int X,
          int Y)
{
Image1->Visible=false;
Image2->Visible=false;
Image3->Visible=false;
Image4->Visible=false;
Image5->Visible=false;
Image6->Visible=true;
Image7->Visible=true;
Image8->Visible=true;
Image9->Visible=true;
Image10->Visible=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm5::FormKeyUp(TObject *Sender, WORD &Key, TShiftState Shift)
{
switch (Key)
	{
	case VK_CAPITAL:
		StatusBar1->Panels->Items[1]->Text = (::GetKeyState(VK_CAPITAL)) ? "CapsLock" : "";
		break;
	case VK_NUMLOCK:
		StatusBar1->Panels->Items[2]->Text = (::GetKeyState(VK_NUMLOCK)) ? "NumLock" : "";
		break;
}
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Image6Click(TObject *Sender)
{
if(Image6)
{
	Edit2->Text="1";
	ShowMessage(" ���� ������ ��������� ! ");
}
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Image7Click(TObject *Sender)
{
  if(Image7)
{
	Edit2->Text="2";
	ShowMessage(" ���� ������ ��������� ! ");
}
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Image8Click(TObject *Sender)
{
if(Image8)
{
	Edit2->Text="3";
	ShowMessage(" ���� ������ ��������� ! ");
}
}

//---------------------------------------------------------------------------

void __fastcall TForm5::Image9Click(TObject *Sender)
{
 if(Image9)
{
	Edit2->Text="4";
	ShowMessage(" ���� ������ ��������� ! ");
}
}
//---------------------------------------------------------------------------

void __fastcall TForm5::Image10Click(TObject *Sender)
{
if(Image10)
{
	Edit2->Text="5";
	ShowMessage(" ���� ������ ��������� ! ");
}
}
//---------------------------------------------------------------------------

void __fastcall TForm5::N2Click(TObject *Sender)
{
Form5->Hide();
Form3->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm5::N12Click(TObject *Sender)
{
Form6->Show();
}
//---------------------------------------------------------------------------

