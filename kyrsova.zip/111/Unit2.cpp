//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit2.h"
#include <File1.h>
#include "Project1PCH1.h"
#include "Unit1.h"
#include "FileEditor.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm2::Button1Click(TObject *Sender)
{
char log[40], pass[20], pass2[20], firstname[40],name[40],lastname [40], sex [40], phone[40],index_self[40];
int age;
buyer u;
 AnsiString tmp=Edit1->Text;
 strcpy(log,tmp.c_str());
 tmp=Edit2->Text;
 strcpy(pass,tmp.c_str());
 tmp=Edit3->Text;
 strcpy(pass2,tmp.c_str());
 tmp=Edit4->Text;
 strcpy(firstname,tmp.c_str());
 tmp=Edit5->Text;
 strcpy(name,tmp.c_str());
 tmp=Edit6->Text;
 strcpy(lastname,tmp.c_str());
 tmp=Edit7->Text;
 strcpy(sex,tmp.c_str());
 tmp=Edit8->Text;
 u.setage(StrToInt(tmp));;
 tmp=Edit9->Text;
 strcpy(phone,tmp.c_str());
 tmp=Edit10->Text;
 strcpy(index_self,tmp.c_str());
 if (Edit1->Text=="" || Edit2->Text=="")
 {
 MessageBox(Handle,L"��������� ����",L"���������",MB_OK| MB_ICONASTERISK) == IDOK;
 }

  else if (SearchLogin(log) )
  {
	 MessageBox(Handle,L"���� ��� ����",L"���������",MB_OK| MB_ICONASTERISK) == IDOK;
	 Edit1->SetFocus();
  }

  else if (strcmp(pass,pass2)!=0) {
	 MessageBox(Handle,L"����� �� ���������",L"���������",MB_OK| MB_ICONASTERISK) == IDOK;
	 Edit2->SetFocus();
  }
  else
  {
	 buyer u;
	 u.setlogin(log);
	 u.setpassword(pass);
	 u.setname(name);
	 u.setfirstname(firstname);
	 u.setlastname(lastname);
	 u.setsex(sex);
	 u.setphone(phone);
	 u.setindex_self(index_self);
	 WriteToFileBuyer(u);
	 MessageBox(Handle,L"��������� ������� ������",L"���������",MB_OK| MB_ICONASTERISK) == IDOK;
	 Form2->Hide();
	 Form1->Show();
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormClose(TObject *Sender, TCloseAction &Action)
{
    Form1->Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormCreate(TObject *Sender)
{
{
for( int i=0; i<2; i++ )
	{
	 StatusBar1->Panels->Add();
	 StatusBar1->Panels->Items[i]->Width = StatusBar1->Parent->Width/2;
	}
}
}
//---------------------------------------------------------------------------

void __fastcall TForm2::FormKeyUp(TObject *Sender, WORD &Key, TShiftState Shift)
{
switch (Key)
	{
	case VK_CAPITAL:
		StatusBar1->Panels->Items[0]->Text = (::GetKeyState(VK_CAPITAL)) ? "CapsLock" : "";
		break;
	case VK_NUMLOCK:
		StatusBar1->Panels->Items[1]->Text = (::GetKeyState(VK_NUMLOCK)) ? "NumLock" : "";
		break;
}
}
//---------------------------------------------------------------------------

