//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit8.h"
#include "File1.h"
#include "File1.h"
#include "Project1PCH1.h"
#include "Unit1.h"
#include "Unit2.h"
#include "Unit3.h"
#include "Unit4.h"
#include "Unit6.h"
#include "Unit7.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm8 *Form8;
//---------------------------------------------------------------------------
__fastcall TForm8::TForm8(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void FillStringGrid(int N, order arr[100],TStringGrid* StringGrid1,bool all=false)
{
	for (int i=0; i < StringGrid1->RowCount; i++)
  for (int j=0; j<StringGrid1->ColCount;j++) StringGrid1->Cells[j][i]="";
  StringGrid1->RowCount=6;
  StringGrid1->Cells[1][0]="�����";
  StringGrid1->Cells[2][0]="���� �����������";
  StringGrid1->Cells[3][0]="��������� ����������";
  int K=0;
  for (int i = 0; i < N; i++)
  {
	if(strcmp(arr[i].getmoto().getname(),"")!=0)
	{
		if(all || !arr[i].getaccepted())
		{
			StringGrid1->Cells[1][K+1]=arr[i].getmoto().getname();
			StringGrid1->Cells[2][K+1]=arr[i].getobj_buyer().getlogin();
			StringGrid1->Cells[3][K+1]=(arr[i].getaccepted()) ? "+" : "-";
			StringGrid1->Cells[99][K+1]=i;
			K++;
			StringGrid1->RowCount++;
		}
	}
  }
}
void FillStringGrid2(int N, order arr[100],TStringGrid* StringGrid2,bool all=false)
{
  for (int i=0; i < StringGrid2->RowCount; i++)
  for (int j=0; j<StringGrid2->ColCount;j++) StringGrid2->Cells[j][i]="";
  StringGrid2->RowCount=6;
  StringGrid2->Cells[1][0]="�����";
  StringGrid2->Cells[2][0]="���� �����������";
  StringGrid2->Cells[3][0]="��������� ����������";
  int K=0;
  for (int i = 0; i < N; i++)
  {
	if(strcmp(arr[i].getobj_car().getname(),"")!=0)
	{
		if(all || !arr[i].getaccepted())
		{
			StringGrid2->Cells[1][K+1]=arr[i].getobj_car().getname();
			StringGrid2->Cells[2][K+1]=arr[i].getobj_buyer().getlogin();
			StringGrid2->Cells[3][K+1]=(arr[i].getaccepted()) ? "+" : "-";
			StringGrid2->Cells[99][K+1]=i;
			K++;
			StringGrid2->RowCount++;
		}
	}
  }

}
void FillStringGrid3(int N, order arr[100],TStringGrid* StringGrid3,bool all=false)
{
  for (int i=0; i < StringGrid3->RowCount; i++)
  for (int j=0; j<StringGrid3->ColCount;j++) StringGrid3->Cells[j][i]="";
  StringGrid3->RowCount=6;
  StringGrid3->Cells[1][0]="�����";
  StringGrid3->Cells[2][0]="���� �����������";
  StringGrid3->Cells[3][0]="��������� ����������";
  int K=0;
  for (int i = 0; i < N; i++)
  {
	if(strcmp(arr[i].getplane_obj().getname(),"")!=0)
	{
		if(all || !arr[i].getaccepted())
		{
			StringGrid3->Cells[1][K+1]=arr[i].getplane_obj().getname();
			StringGrid3->Cells[2][K+1]=arr[i].getobj_buyer().getlogin();
			StringGrid3->Cells[3][K+1]=(arr[i].getaccepted()) ? "+" : "-";
			StringGrid3->Cells[99][K+1]=i;
			K++;
			StringGrid3->RowCount++;
		}
	}
  }

}
void __fastcall TForm8::FormShow(TObject *Sender)
{
for (int i = 0; i < StatusBar1->Panels->Count; i++)
{
 StatusBar1->Panels->Items[0]->Text=Form1->Edit1->Text;
}
order arr[100];
 int N;
 N=ReadFromFileO(arr);
 FillStringGrid(N,arr,StringGrid1,true);
 FillStringGrid2(N,arr,StringGrid2,true);
  FillStringGrid3(N,arr,StringGrid3,true);
}
//---------------------------------------------------------------------------

void __fastcall TForm8::N1Click(TObject *Sender)
{
if(StringGrid1->Cells[3][StringGrid1->Row]=="-")
{
order arr[100];
int i=StrToInt(StringGrid1->Cells[99][StringGrid1->Row]);
int N=ReadFromFileO(arr);
arr[i].setaccepted(true);
 RewriteFileO(arr,N);
  FillStringGrid(N,arr,StringGrid1);
   DeleteMotoByName(arr[i].getmoto().getname());
}

}
//---------------------------------------------------------------------------

void __fastcall TForm8::N2Click(TObject *Sender)
{
if(StringGrid2->Cells[3][StringGrid2->Row]=="-")
{
	order arr[100];
	int i=StrToInt(StringGrid2->Cells[99][StringGrid2->Row]);
	int N=ReadFromFileO(arr);
	arr[i].setaccepted(true);
	RewriteFileO(arr,N);
	FillStringGrid2(N,arr,StringGrid2);
	ShowMessage(arr[i].getobj_car().getname());
   	DeleteCarsByName(arr[i].getobj_car().getname());
}
}
//---------------------------------------------------------------------------

void __fastcall TForm8::N3Click(TObject *Sender)
{
if(StringGrid3->Cells[3][StringGrid3->Row]=="-")
{
order arr[100];
int i=StrToInt(StringGrid3->Cells[99][StringGrid3->Row]);
int N=ReadFromFileO(arr);
arr[i].setaccepted(true);
 RewriteFileO(arr,N);
   FillStringGrid3(N,arr,StringGrid3);
	DeletePlaneByName(arr[i].getplane_obj().getname());
}
}
//---------------------------------------------------------------------------

void __fastcall TForm8::N5Click(TObject *Sender)
{
 Form8->Hide();
 Form3->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm8::N6Click(TObject *Sender)
{
Form8->Hide();
Form7->Show();
}
//---------------------------------------------------------------------------


void __fastcall TForm8::FormCreate(TObject *Sender)
{
for( int i=0; i<2; i++ )
	{
	StatusBar1->Panels->Add();
	StatusBar1->Panels->Items[i]->Width = StatusBar1->Parent->Width/3;
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm8::FormKeyUp(TObject *Sender, WORD &Key, TShiftState Shift)
{
switch (Key)
	{
	case VK_CAPITAL:
		StatusBar1->Panels->Items[1]->Text = (::GetKeyState(VK_CAPITAL)) ? "CapsLock" : "";
		break;
	case VK_NUMLOCK:
		StatusBar1->Panels->Items[2]->Text = (::GetKeyState(VK_NUMLOCK)) ? "NumLock" : "";
		break;
}
}
//---------------------------------------------------------------------------

void __fastcall TForm8::N12Click(TObject *Sender)
{
Form6->Show();
}
//---------------------------------------------------------------------------

