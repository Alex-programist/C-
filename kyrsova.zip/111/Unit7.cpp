//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit7.h"
#include "File1.h"
#include "File1.h"
#include "Project1PCH1.h"
#include "Unit3.h"
#include "Unit1.h"
#include "Unit2.h"
#include "Unit4.h"
#include "Unit6.h"
#include "FileEditor.h"
#include "Unit8.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm7 *Form7;
//---------------------------------------------------------------------------
__fastcall TForm7::TForm7(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
 void FillStringGrid(int N, moto arr[100],TStringGrid* StringGrid1)
{
  for (int i=0; i < StringGrid1->RowCount; i++)
  for (int j=0; j<StringGrid1->ColCount;j++) StringGrid1->Cells[j][i]="";
  StringGrid1->RowCount=16;
 StringGrid1->Cells[0][0]="�����";
   StringGrid1->Cells[1][0]="������";
   StringGrid1->Cells[2][0]="г� �������";
 StringGrid1->Cells[3][0]="��'�� �������";
 StringGrid1->Cells[4][0]="����������";
  StringGrid1->Cells[5][0]="ʳ������ ������� ����";
   StringGrid1->Cells[6][0]="����";
	StringGrid1->Cells[7][0]="��� ������";
	StringGrid1->Cells[8][0]="��'�� ����";
		 StringGrid1->Cells[9][0]="ֳ��";
	 StringGrid1->Cells[10][0]="��� ������";
  for (int i = 0; i < N; i++)
  {
	StringGrid1->Cells[0][i+1]=arr[i].getname();
	StringGrid1->Cells[1][i+1]=arr[i].getmodel();
	StringGrid1->Cells[2][i+1]=arr[i].getyear();
	StringGrid1->Cells[3][i+1]=arr[i].getengine();
	StringGrid1->Cells[4][i+1]=arr[i].getpower();
	StringGrid1->Cells[5][i+1]=arr[i].getnumber_of_seats();
	StringGrid1->Cells[6][i+1]=arr[i].getcolor();
	StringGrid1->Cells[7][i+1]=arr[i].getkind_of_fuel();
	StringGrid1->Cells[8][i+1]=arr[i].gettank_volume();
	StringGrid1->Cells[9][i+1]=arr[i].getprice();
	StringGrid1->Cells[10][i+1]=arr[i].gettype_of_body();
	StringGrid1->Cells[11][i+1]=arr[i].getImg();

	StringGrid1->RowCount++;
  }
}
 void FillStringGrid2(int N, car arr[100],TStringGrid* StringGrid2)
{
  for (int i=0; i < StringGrid2->RowCount; i++)
  for (int j=0; j<StringGrid2->ColCount;j++) StringGrid2->Cells[j][i]="";
  StringGrid2->RowCount=16;
  StringGrid2->Cells[0][0]="�����";
   StringGrid2->Cells[1][0]="������";
   StringGrid2->Cells[2][0]="г� �������";
 StringGrid2->Cells[3][0]="��'�� �������";
 StringGrid2->Cells[4][0]="����������";
  StringGrid2->Cells[5][0]="ʳ������ ������� ����";
   StringGrid2->Cells[6][0]="����";
	StringGrid2->Cells[7][0]="��� ������";
	StringGrid2->Cells[8][0]="��'�� ����";
		 StringGrid2->Cells[9][0]="ֳ��";
	 StringGrid2->Cells[10][0]="��� ������";
	  StringGrid2->Cells[11][0]="��� ���";
	   StringGrid2->Cells[12][0]="��� �������";
		StringGrid2->Cells[13][0]="ʳ������ ������";
  for (int i = 0; i < N; i++)
  {
	StringGrid2->Cells[0][i+1]=arr[i].getname();
	StringGrid2->Cells[1][i+1]=arr[i].getmodel();
	StringGrid2->Cells[2][i+1]=arr[i].getyear();
	StringGrid2->Cells[3][i+1]=arr[i].getengine();
	StringGrid2->Cells[4][i+1]=arr[i].getpower();
	StringGrid2->Cells[5][i+1]=arr[i].getnumber_of_seats();
	StringGrid2->Cells[6][i+1]=arr[i].getcolor();
	StringGrid2->Cells[7][i+1]=arr[i].getkind_of_fuel();
	StringGrid2->Cells[8][i+1]=arr[i].gettank_volume();
	StringGrid2->Cells[9][i+1]=arr[i].getprice();
	StringGrid2->Cells[10][i+1]=arr[i].gettype_of_body();
	StringGrid2->Cells[11][i+1]=arr[i].getKPP();
	StringGrid2->Cells[12][i+1]=arr[i].gettype_of_drive();
	StringGrid2->Cells[13][i+1]=arr[i].getdoor();
	StringGrid2->Cells[14][i+1]=arr[i].getqaz();
	StringGrid2->RowCount++;
  }
}
 void FillStringGrid3(int N, plane arr[100],TStringGrid* StringGrid3)
{
  for (int i=0; i < StringGrid3->RowCount; i++)
  for (int j=0; j<StringGrid3->ColCount;j++) StringGrid3->Cells[j][i]="";
  StringGrid3->RowCount=16;
StringGrid3->Cells[0][0]="�����";
   StringGrid3->Cells[1][0]="������";
   StringGrid3->Cells[2][0]="г� �������";
 StringGrid3->Cells[3][0]="��'�� �������";
 StringGrid3->Cells[4][0]="����������";
  StringGrid3->Cells[5][0]="ʳ������ ������� ����";
   StringGrid3->Cells[6][0]="����";
	StringGrid3->Cells[7][0]="��� ������";
	StringGrid3->Cells[8][0]="��'�� ����";
		 StringGrid3->Cells[9][0]="ֳ��";
		 StringGrid3->Cells[10][0]="ʳ������ ������";
		 StringGrid3->Cells[11][0]="ʳ������ ����";
  for (int i = 0; i < N; i++)
  {
	StringGrid3->Cells[1][i+1]=arr[i].getname();
	StringGrid3->Cells[2][i+1]=arr[i].getmodel();
	StringGrid3->Cells[3][i+1]=arr[i].getyear();
	StringGrid3->Cells[4][i+1]=arr[i].getengine();
	StringGrid3->Cells[5][i+1]=arr[i].getpower();
	StringGrid3->Cells[6][i+1]=arr[i].getnumber_of_seats();
	StringGrid3->Cells[7][i+1]=arr[i].getcolor();
	StringGrid3->Cells[8][i+1]=arr[i].getkind_of_fuel();
	StringGrid3->Cells[9][i+1]=arr[i].gettank_volume();
	StringGrid3->Cells[10][i+1]=arr[i].getprice();
	StringGrid3->Cells[14][i+1]=arr[i].getnumber_door();
	StringGrid3->Cells[14][i+1]=arr[i].getnumber_window();
	StringGrid3->Cells[15][i+1]=arr[i].getqwe();
	StringGrid3->RowCount++;
  }
}
void __fastcall TForm7::Button1Click(TObject *Sender)
{
MessageBox(Handle,L"����������� ���������",L"Auto.Cars",MB_OK| MB_ICONASTERISK) == IDOK;
StringGrid1->Options = StringGrid1->Options << goEditing;
StringGrid2->Options = StringGrid2->Options << goEditing;
StringGrid3->Options = StringGrid3->Options << goEditing;
}
//---------------------------------------------------------------------------


void __fastcall TForm7::Timer1Timer(TObject *Sender)
{
StringGrid2->Visible=false;
StringGrid1->Visible=true;
moto arr[100];
 int N;
 N=ReadFromFileMoto(arr);
 FillStringGrid(N,arr,StringGrid1);
 Timer1->Interval=111111111;
}
//---------------------------------------------------------------------------



void __fastcall TForm7::Timer2Timer(TObject *Sender)
{
car arr[100];
 int N;
 N=ReadFromFileCar(arr);
 FillStringGrid2(N,arr,StringGrid2);
  Timer2->Interval=111111111;
}
//---------------------------------------------------------------------------

void __fastcall TForm7::N2Click(TObject *Sender)
{
Form7->Hide();
Form3->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm7::N3Click(TObject *Sender)
{
Form7->Hide();
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Image2Click(TObject *Sender)
{
if (MessageBox(Handle,L"�� �������i, �� ������ �������� �����?",L"�i�����������",MB_YESNOCANCEL | MB_ICONASTERISK) == IDYES) {
  int Index = StringGrid1->Selection.Top;
if((Index < StringGrid1->RowCount)&&(StringGrid1->RowCount>2))
  {
  for(int i=Index; i<StringGrid1->RowCount-1; i++)
	 StringGrid1->Rows[i] = StringGrid1->Rows[i+1];
	 StringGrid1->RowCount--;
  }
else
		{
		  StringGrid1->Rows[StringGrid1->RowCount-1]->Clear();
		}
}

else
{}
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Image4Click(TObject *Sender)
{
Form4->Show();
Form4->ComboBox1->Visible=false;
Form4->ComboBox4->Visible=false;
Form4->ComboBox5->Visible=false;
Form4->ComboBox8->Visible=false;
Form4->ComboBox9->Visible=false;
Form4->ComboBox10->Visible=false;
Form4->ComboBox11->Visible=false;
Form4->Button1->Visible=false;
Form4->Button4->Visible=false;
Form4->Edit16->Visible=false;
Form4->Edit9->Visible=false;
Form4->Edit13->Visible=false;
Form4->Edit14->Visible=false;
Form4->ComboBox15->Visible=false;////
Form4->Button5->Visible=false;////
Form4->Edit15->Visible=false;////
Form4->Edit11->Visible=true;///
Form4->Edit10->Visible=true;///
Form4->Edit2->Visible=true;///
Form4->Edit6->Visible=true;///
Form4->ComboBox2->Visible=true;///
Form4->ComboBox12->Visible=true;///
Form4->ComboBox13->Visible=true;///
Form4->ComboBox14->Visible=true;///
Form4->ComboBox7->Visible=true;///
Form4->ComboBox6->Visible=true;///
Form4->Edit8->Visible=true;///
Form4->Button2->Visible=true;
Form4->Button3->Visible=true;
Form4->ComboBox2->Visible=true;
Form4->Label1->Caption="��������� ����";
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Timer3Timer(TObject *Sender)
{
 plane arr[100];
 int N;
 N=ReadFromFilePlane(arr);
 FillStringGrid3(N,arr,StringGrid3);
  Timer3->Interval=111111111;
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Image3Click(TObject *Sender)
{
int N = 0;
int k = 0;
car arr[100];
AnsiString tmp;
for (int i=0; i < StringGrid2->RowCount; i++)
	 {
	  if (StringGrid2->Cells[0][i+1]!="")
	  {

		 tmp=StringGrid2->Cells[0][i+1];
		 arr[k].setname(tmp.c_str());

		tmp=StringGrid2->Cells[1][i+1];
		 arr[k].setmodel(tmp.c_str());

		tmp=StringGrid2->Cells[2][i+1];
		 arr[k].setyear(StrToInt(tmp));

		 tmp=StringGrid2->Cells[3][i+1];
		arr[k].setengine(StrToFloat(tmp));

		tmp=StringGrid2->Cells[4][i+1];
		  arr[k].setpower(StrToFloat(tmp));

		tmp=StringGrid2->Cells[5][i+1];
		 arr[k].setnumber_of_seats(StrToInt(tmp));

		 tmp=StringGrid2->Cells[6][i+1];
		  arr[k].setcolor(tmp.c_str());

		 tmp=StringGrid2->Cells[7][i+1];
	   arr[k].setkind_of_fuel(tmp.c_str());

		  tmp=StringGrid2->Cells[8][i+1];
		  arr[k].settank_volume(StrToFloat(tmp));

		 tmp=StringGrid2->Cells[9][i+1];
		arr[k].setprice(StrToFloat(tmp));

		 tmp=StringGrid2->Cells[10][i+1];
		 arr[k].settype_of_body(tmp.c_str());

		tmp=StringGrid2->Cells[11][i+1];
		 arr[k].setKPP(tmp.c_str());

		 tmp=StringGrid2->Cells[12][i+1];
		 arr[k].settype_of_drive(tmp.c_str());

		 tmp=StringGrid2->Cells[13][i+1];
		 arr[k].setdoor (StrToInt(tmp));

			 tmp=StringGrid2->Cells[14][i+1];
			   arr[i].setqaz(tmp.c_str());

		 N++; k++;
	  }
	 }
   RewriteFileCar(arr,N);
    MessageBox(Handle,L"�������� ���� ���������",L"ϳ����������",MB_OK| MB_ICONASTERISK) == IDOK;
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Image5Click(TObject *Sender)
{
if (MessageBox(Handle,L"�� �������i, �� ������ �������� �����?",L"�i�����������",MB_YESNOCANCEL | MB_ICONASTERISK) == IDYES) {
  int Index = StringGrid2->Selection.Top;
if((Index < StringGrid2->RowCount)&&(StringGrid2->RowCount>2))
  {
  for(int i=Index; i<StringGrid2->RowCount-1; i++)
	 StringGrid2->Rows[i] = StringGrid2->Rows[i+1];
	 StringGrid2->RowCount--;
  }
else
		{
		  StringGrid2->Rows[StringGrid2->RowCount-1]->Clear();
		}
}

else
{}
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Image6Click(TObject *Sender)
{
Form4->Show();
Form4->ComboBox1->Visible=true; //
Form4->Edit2->Visible=true;//
Form4->ComboBox3->Visible=true; //
Form4->Edit6->Visible=true;    //
Form4->ComboBox4->Visible=true; //
Form4->ComboBox5->Visible=true;  //
Form4->ComboBox6->Visible=true;  //
Form4->ComboBox7->Visible=true;  //
Form4->ComboBox8->Visible=true;    //
Form4->ComboBox9->Visible=true;   //
Form4->ComboBox10->Visible=true;   //
Form4->ComboBox11->Visible=true;
Form4->Button4->Visible=true;   //
Form4->Button1->Visible=true;    //
Form4->Edit10->Visible=true;//
Form4->Edit16->Visible=true;//
Form4->Edit11->Visible=false;
Form4->ComboBox12->Visible=false;
Form4->ComboBox13->Visible=false;
Form4->ComboBox14->Visible=false;
Form4->Button2->Visible=false;
Form4->ComboBox2->Visible=false; ///
Form4->Edit9->Visible=false;
 Form4->Edit8->Visible=false;///
Form4->Edit13->Visible=false;
Form4->Edit14->Visible=false;
Form4->Button3->Visible=false;
Form4->ComboBox15->Visible=false;///
Form4->Button5->Visible=false;////
Form4->Edit15->Visible=false;////
Form4->Label1->Caption="��������� ����";
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Image7Click(TObject *Sender)
{
int N = 0;
int k = 0;
 moto arr[100];
 AnsiString tmp;
 for (int i=0; i < StringGrid1->RowCount; i++)
	   {
		  if (StringGrid1->Cells[0][i+1]!="")
		  {

			   tmp=StringGrid1->Cells[0][i+1];
				 arr[i].setname(tmp.c_str());

				tmp=StringGrid1->Cells[1][i+1];
				 arr[i].setmodel(tmp.c_str());

			  tmp=StringGrid1->Cells[2][i+1];
			   arr[i].setyear(StrToInt(tmp));

			   tmp=StringGrid1->Cells[3][i+1];
				arr[i].setengine(StrToFloat(tmp));

				tmp=StringGrid1->Cells[4][i+1];
				  arr[i].setpower(StrToFloat(tmp));

				tmp=StringGrid1->Cells[5][i+1];
				 arr[i].setnumber_of_seats(StrToInt(tmp));

			   tmp=StringGrid1->Cells[6][i+1];
				  arr[i].setcolor(tmp.c_str());

			   tmp=StringGrid1->Cells[7][i+1];
			 arr[i].setkind_of_fuel(tmp.c_str());

				  tmp=StringGrid1->Cells[8][i+1];
				  arr[i].settank_volume(StrToFloat(tmp));

				 tmp=StringGrid1->Cells[9][i+1];
			  arr[i].setprice(StrToFloat(tmp));

				 tmp=StringGrid1->Cells[10][i+1];
			   arr[i].settype_of_body(tmp.c_str());

				   tmp=StringGrid1->Cells[11][i+1];
			   arr[i].setImg(tmp.c_str());

				 N++; k++;
		  }
	   }
	 RewriteFileMoto(arr,N);
	 MessageBox(Handle,L"�������� ���� ���������",L"ϳ����������",MB_OK| MB_ICONASTERISK) == IDOK;
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Image8Click(TObject *Sender)
{
if (MessageBox(Handle,L"�� �������i, �� ������ �������� �����?",L"�i�����������",MB_YESNOCANCEL | MB_ICONASTERISK) == IDYES) {
  int Index = StringGrid3->Selection.Top;
if((Index < StringGrid3->RowCount)&&(StringGrid3->RowCount>2))
  {
  for(int i=Index; i<StringGrid3->RowCount-1; i++)
	 StringGrid3->Rows[i] = StringGrid3->Rows[i+1];
	 StringGrid3->RowCount--;
  }
else
		{
		  StringGrid3->Rows[StringGrid3->RowCount-1]->Clear();
		}
}

else
{}
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Image9Click(TObject *Sender)
{
Form4->Show();
Form4->Edit9->Visible=true;////
Form4->Edit13->Visible=true;////
Form4->Edit1->Visible=true;////
Form4->Edit14->Visible=false;
Form4->Edit11->Visible=false;
Form4->Button6->Visible=true;
Form4->Edit1->Visible=true;
Form4->Edit10->Visible=true;////
Form4->Edit14->Visible=true;////
Form4->Edit15->Visible=true;////
Form4->Edit2->Visible=true;////
Form4->Edit6->Visible=true;////
Form4->ComboBox3->Visible=true;////
Form4->ComboBox4->Visible=true;////
Form4->ComboBox15->Visible=true;////
Form4->ComboBox6->Visible=true;////
Form4->ComboBox7->Visible=true;////
Form4->ComboBox12->Visible=false;
Form4->ComboBox13->Visible=false;
Form4->ComboBox14->Visible=false;
Form4->Button2->Visible=false;
Form4->ComboBox2->Visible=false;
Form4->ComboBox1->Visible=false;
Form4->ComboBox4->Visible=true;
Form4->ComboBox5->Visible=true;
Form4->ComboBox8->Visible=false;
Form4->ComboBox9->Visible=false;
Form4->ComboBox10->Visible=false;
Form4->ComboBox11->Visible=false;
Form4->Button1->Visible=false;
Form4->Edit16->Visible=false;
Form7->Image2->Visible=false;
Form7->Image4->Visible=false;
 Form4->Label1->Caption="��������� �����";
}
//---------------------------------------------------------------------------

void __fastcall TForm7::Image10Click(TObject *Sender)
{
int N = 0;
int k = 0;
plane arr[100];
 AnsiString tmp;
 for (int i=0; i < StringGrid1->RowCount; i++)
	   {
		  if (StringGrid3->Cells[0][i+1]!="")
		  {

			   tmp=StringGrid3->Cells[0][i+1];
				 arr[i].setname(tmp.c_str());

				tmp=StringGrid3->Cells[1][i+1];
				 arr[i].setmodel(tmp.c_str());

			  tmp=StringGrid3->Cells[2][i+1];
			   arr[i].setyear(StrToInt(tmp));

			   tmp=StringGrid3->Cells[3][i+1];
				arr[i].setengine(StrToFloat(tmp));

				tmp=StringGrid3->Cells[4][i+1];
				  arr[i].setpower(StrToFloat(tmp));

				tmp=StringGrid3->Cells[5][i+1];
				 arr[i].setnumber_of_seats(StrToInt(tmp));

			   tmp=StringGrid3->Cells[6][i+1];
				  arr[i].setcolor(tmp.c_str());

			   tmp=StringGrid3->Cells[7][i+1];
			 arr[i].setkind_of_fuel(tmp.c_str());

				  tmp=StringGrid3->Cells[8][i+1];
				  arr[i].settank_volume(StrToFloat(tmp));

				 tmp=StringGrid3->Cells[9][i+1];
			  arr[i].setprice(StrToFloat(tmp));

				 tmp=StringGrid3->Cells[10][i+1];
			   arr[i].setnumber_door(StrToInt(tmp));

				tmp=StringGrid3->Cells[11][i+1];
			   arr[i].setnumber_window(StrToInt(tmp));

				   tmp=StringGrid3->Cells[12][i+1];
			   arr[i].setqwe(tmp.c_str());

				 N++; k++;
		  }
	   }
	 RewriteFilePlane(arr,N);
	 MessageBox(Handle,L"�������� ���� ���������",L"ϳ����������",MB_OK| MB_ICONASTERISK) == IDOK;
}
//---------------------------------------------------------------------------

void __fastcall TForm7::FormCreate(TObject *Sender)
{
for( int i=0; i<2; i++ )
	{
	StatusBar1->Panels->Add();
	StatusBar1->Panels->Items[i]->Width = StatusBar1->Parent->Width/3;
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm7::FormShow(TObject *Sender)
{
for (int i = 0; i < StatusBar1->Panels->Count; i++)
{
 StatusBar1->Panels->Items[0]->Text=Form1->Edit1->Text;
}
}
//---------------------------------------------------------------------------

void __fastcall TForm7::FormKeyUp(TObject *Sender, WORD &Key, TShiftState Shift)
{
switch (Key)
	{
	case VK_CAPITAL:
		StatusBar1->Panels->Items[1]->Text = (::GetKeyState(VK_CAPITAL)) ? "CapsLock" : "";
		break;
	case VK_NUMLOCK:
		StatusBar1->Panels->Items[2]->Text = (::GetKeyState(VK_NUMLOCK)) ? "NumLock" : "";
		break;
}
}
//---------------------------------------------------------------------------

