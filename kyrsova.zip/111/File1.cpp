#include <File1.h>
#include <FileEditor.h>
#include <fstream>
#include <iostream>
buyer current_user;
//----------------------------------------------------------
//----------------------------------------------------------
	   //user get/set
//----------------------------------------------------------
//----------------------------------------------------------
char* user::getlogin()
{
	return login;
}
char* user::getpassword()
{
	return password;
}
char* user::getfirstname()
{
	return firstname;
}
char* user::getname()
{
	return name;
};
char* user::getlastname()
{
	return lastname;
};
char* user::getsex()
{
	return sex;
};
int user::getage()
{
	return age;
};
char* user::getphone()
{
	return phone;
};
char* saler::getadress()
{
	return adress;
}
void user::setlogin(char*login)
{
	strcpy(this->login, login);
}
void user::setpassword(char*password)
{
	strcpy(this->password, password);
}
void user::setfirstname(char*firstname)
{
	strcpy(this->firstname, firstname);
}
void user::setname(char*name)
{
	strcpy(this->name, name);
}
void user::setlastname(char*lastname)
{
	strcpy(this->lastname, lastname);
}
void user::setsex(char*sex)
{
	strcpy(this->sex, sex);
}
void user::setage(int age)
{
	this->age=age;
}
void user::setphone(char*phone)
{
	strcpy(this->phone, phone);
}
//------------------------------------------------------------
//------------------------------------------------------------
		//buyer get/set
//------------------------------------------------------------
//------------------------------------------------------------
char* buyer::getindex_self()
{
	return index_self;
}
void buyer::setindex_self(char* index_self)
{
	strcpy(this->index_self, index_self);
}
//------------------------------------------------------------
//------------------------------------------------------------
//------------------------------------------------------------
		//seller get/set
//------------------------------------------------------------
//------------------------------------------------------------
void saler::setadress(char*adress)
{
	strcpy(this->adress, adress);
}
//------------------------------------------------------------
//------------------------------------------------------------
//------------------------------------------------------------
		//administrator get/set
//------------------------------------------------------------
//------------------------------------------------------------
char* administrator::getEmail()
{
	return email;
}
void administrator::setEmail(char* email)
{
	strcpy(this->email, email);
}
//------------------------------------------------------------
//------------------------------------------------------------
	   //transport get/set
//------------------------------------------------------------
//------------------------------------------------------------
char* transport::getname()
{
	return name;
}
char* transport::getmodel()
{
	return model;
}
int transport::getyear()
{
	return year;
}
float transport::getengine()
{
	return engine;
}
float transport::getpower()
{
	return power;
}
int transport::getnumber_of_seats()
{
	return number_of_seats;
}
char* transport::getcolor()
{
	return color;
}
char* transport::getkind_of_fuel()
{
	return kind_of_fuel;
}
float transport::gettank_volume()
{
	return tank_volume;
}
float transport::getprice()
{
	return price;
}
void transport::setname(char*name)
{
	strcpy(this->name, name);
}
void transport::setmodel(char*model)
{
	strcpy(this->model, model);
}
void transport::setyear(int year)
{
	this->year=year;
}
void transport::setengine(float engine)
{
	this->engine=engine;
}
void transport::setpower(float power)
{
	this->power=power;
}
void transport::setnumber_of_seats(int number_of_seats)
{
	this->number_of_seats=number_of_seats;
}
void transport::setcolor(char*color)
{
	strcpy(this->color, color);
}
void transport::setkind_of_fuel(char*kind_of_fuel)
{
	strcpy(this->kind_of_fuel, kind_of_fuel);
}
void transport::settank_volume(float tank_volume)
{
	this->tank_volume=tank_volume;
}
void transport::setprice(float price)
{
	this->price=price;
}
//----------------------------------------------------------
//----------------------------------------------------------
	   //Car get/set
//----------------------------------------------------------
//----------------------------------------------------------
char* car::gettype_of_body()
{
	return type_of_body;
}
char* car::getKPP()
{
	return KPP;
}
char* car::gettype_of_drive()
{
	return type_of_drive;
}
int car::getdoor()
{
	return door;
}
char* car::getqaz()
{
	return qaz;
}
void car::settype_of_body(char*type_of_body)
{
	strcpy(this->type_of_body, type_of_body);
}
void car::setKPP(char*KPP)
{
	strcpy(this->KPP, KPP);
}
void car::settype_of_drive(char*type_of_drive)
{
	strcpy(this->type_of_drive, type_of_drive);
}
void car::setdoor(int door)
{
	this->door=door;
}
void car::setqaz(char*qaz)
{
	strcpy(this->qaz, qaz);
}
//----------------------------------------------------------
//----------------------------------------------------------
	   //moto get/set
//----------------------------------------------------------
//----------------------------------------------------------
char* moto::gettype_of_body()
{
	return type_of_body;
}
void moto::settype_of_body(char*type_of_body)
{
	strcpy(this->type_of_body, type_of_body);
}
  char* moto::getImg()
{
	return img;
}
void moto::setImg(char*img)
{
	strcpy(this->img, img);
}



//----------------------------------------------------------
//----------------------------------------------------------
	   //order get/set
//----------------------------------------------------------
//----------------------------------------------------------

buyer order::getobj_buyer()
{
	return obj_buyer;
}
bool order::getaccepted()
{
	return accepted;
}
 moto order::getmoto()
 {
	return obj;
 }
  car order::getobj_car()
 {
	return obj_car;
 }
  plane order::getplane_obj()
 {
	return obj_plane;
 }
 void order::setobj_buyer(buyer obj_buyer)
{
	this->obj_buyer=obj_buyer;
}
 void order::setaccepted(bool accepted)
{
	this->accepted=accepted;
}
 void order::setmoto(moto obj)
{
	this->obj=obj;
}
 void order::setobj_car(car obj_car)
{
	this->obj_car=obj_car;
}
 void order::setplane(plane obj_plane)
{
	this->obj_plane=obj_plane;
}
//----------------------------------------------------------
//----------------------------------------------------------
	   //plane get/set
//----------------------------------------------------------
//----------------------------------------------------------
	 int plane::getnumber_door()
{
	return number_door;
}
	 int plane::getnumber_window()
{
	return number_window;
}
	 char* plane::getqwe()
{
	return qwe;
}
void plane::setqwe(char* qwe)
{
	strcpy(this->qwe, qwe);
}
void plane::setnumber_door(int number_door)
{
	this->number_door=number_door;
}
void plane::setnumber_window(int number_window)
{
	this->number_window=number_window;
}
//------------------------------------------------------------
//------------------------------------------------------------
		//reviews get/set
//------------------------------------------------------------
//------------------------------------------------------------
char* reviews::getlogin()
{
	return login;
};
char* reviews::gettext()
{
	return text;
};
char* reviews::getmarks()
{
	return marks;
};
void reviews::setlogin(char*login)
{
	strcpy(this->login, login);
}
void reviews::settext(char*text)
{
	strcpy(this->text, text);
}
void reviews::setmarks(char*marks)
{
	strcpy(this->marks, marks);
}
//------------------------------------------------------------
//------------------------------------------------------------
	   //buyer write-read from file
//------------------------------------------------------------
//------------------------------------------------------------
void WriteToFileBuyer(buyer a)
{
   FileEditor<buyer> fe(FileBuyer);
   fe.WriteToFile(a);
};
int ReadFromFileBuyer(buyer arr[100])
{
   FileEditor<buyer> fe(FileBuyer);
   return fe.ReadFromFile(arr);


};
//------------------------------------------------------------
//------------------------------------------------------------
	   //reviews write-read from file
//------------------------------------------------------------
//------------------------------------------------------------
void WriteToFileReviews(reviews r)
{
	ofstream f_out;
	f_out.open("reviews.dat",ios::binary|ios::app);
	 if (f_out.is_open())
	 {
	  f_out.write((char*) &r, sizeof(reviews));
	 }
	f_out.close();
};
int ReadFromFileReviews(reviews arr[1000])
{
	ifstream f_in;
	int i=0;
	f_in.open(FileReviews,ios::binary|ios::in);
	 if (f_in.is_open())
	 {
	  reviews r;
	  while (f_in.read((char*) &r, sizeof(reviews)))
	  {
		  arr[i]=r;
		  i++;
	  }
	 }
	f_in.close();
	return i;
};
int SearchUser(char log[40], char pass[40])
{
	buyer arr[100];
	int N;
	N=ReadFromFileBuyer(arr);
	for (int i = 0; i < N; i++)
	{
	  if (strcmp(arr[i].getlogin(),log)==0)
	  {
		if (strcmp(arr[i].getpassword(),pass)==0)
		{
			current_user=arr[i];
			return 1;
		}
		else
		{
			return 0;
		}
	  }
	}
	return -1;
}
//------------------------------------------------------------
bool SearchLogin(char log[20])
{
	buyer arr[100];
	int N;
	N=ReadFromFileBuyer(arr);
	for (int i = 0; i < N; i++)
	{
	  if (strcmp(arr[i].getlogin(),log)==0) {
		   return true;
	  }
	}
	return false;
}
//------------------------------------------------------------
//------------------------------------------------------------
	   //moto write-read from file
//------------------------------------------------------------
//------------------------------------------------------------
 void WriteToFileMoto(moto m)
{
	ofstream f_out;
	f_out.open("moto.dat",ios::binary|ios::app);
	 if (f_out.is_open())
	 {
	  f_out.write((char*) &m, sizeof(moto));
	 }
	f_out.close();
};
int ReadFromFileMoto(moto arr[100])
{
	ifstream f_in;
	int i=0;
	f_in.open(FileMoto,ios::binary|ios::in);
	 if (f_in.is_open())
	 {
	  moto m;
	  while (f_in.read((char*) &m, sizeof(moto)))
	  {
		  arr[i]=m;
		  i++;
	  }
	 }
	f_in.close();
	return i;
};

void DeleteMotoByName(char*name)
{

	moto arr[100];
	moto arr2[100];
	int K=0;
	int N=ReadFromFileMoto(arr);
	for(int i=0; i<N; i++)
	{
		if(strcmp(arr[i].getname(),name)!=0)
		{
			arr2[K]=arr[i];
			K++;
		}

	}
	RewriteFileMoto(arr2,K);
}
void RewriteFileMoto(moto arr[100], int N)
{
	ofstream f_out;
	f_out.open(FileMoto, ios::binary|ios::out);
	if (f_out.is_open())
	{
		for (int i = 0; i < N; i++)
		{
			f_out.write((char*) &arr[i], sizeof(moto));
		}
	}
	f_out.close();
};
//------------------------------------------------------------
//------------------------------------------------------------
	   //car write-read from file
//------------------------------------------------------------
//------------------------------------------------------------
 void WriteToFileCar(car c)
{
	ofstream f_out;
	f_out.open("car.dat",ios::binary|ios::app);
	 if (f_out.is_open())
	 {
	  f_out.write((char*) &c, sizeof(car));
	 }
	f_out.close();
};
int ReadFromFileCar(car arr[100])
{
	ifstream f_in;
	int i=0;
	f_in.open(FileCar,ios::binary|ios::in);
	 if (f_in.is_open())
	 {
	  car c;
	  while (f_in.read((char*) &c, sizeof(car)))
	  {
		  arr[i]=c;
		  i++;
	  }
	 }
	f_in.close();
	return i;
};

void RewriteFileCar(car arr[100], int N)
{
	ofstream f_out;
	f_out.open(FileCar, ios::binary|ios::out);
	if (f_out.is_open())
	{
		for (int i = 0; i < N; i++)
		{
			f_out.write((char*) &arr[i], sizeof(car));
		}
	}
	f_out.close();
};
void DeleteCarsByName(char*name)
{
	car arr[100];
	car arr2[100];
	int K=0;
	int N=ReadFromFileCar(arr);
	for(int i=0; i<N; i++)
	{
		if(strcmp(arr[i].getname(),name)!=0)
		{
			arr2[K]=arr[i];
			K++;
		}

	}
	RewriteFileCar(arr2,K);
}
//------------------------------------------------------------
//------------------------------------------------------------
	   //plane write-read from file
//------------------------------------------------------------
//------------------------------------------------------------
 void WriteToFilePlane(plane p)
{
	ofstream f_out;
	f_out.open("plane.dat",ios::binary|ios::app);
	 if (f_out.is_open())
	 {
	  f_out.write((char*) &p, sizeof(plane));
	 }
	f_out.close();
};
int ReadFromFilePlane(plane arr[100])
{
	ifstream f_in;
	int i=0;
	f_in.open(FilePlane,ios::binary|ios::in);
	 if (f_in.is_open())
	 {
	  plane p;
	  while (f_in.read((char*) &p, sizeof(plane)))
	  {
		  arr[i]=p;
		  i++;
	  }
	 }
	f_in.close();
	return i;
};
void RewriteFilePlane(plane arr[100], int N)
{
	ofstream f_out;
	f_out.open(FilePlane, ios::binary|ios::out);
	if (f_out.is_open())
	{
		for (int i = 0; i < N; i++)
		{
			f_out.write((char*) &arr[i], sizeof(plane));
		}
	}
	f_out.close();
};
void DeletePlaneByName(char*name)
{

	plane arr[100];
	plane arr2[100];
	int K=0;
	int N=ReadFromFilePlane(arr);
	for(int i=0; i<N; i++)
	{
		if(strcmp(arr[i].getname(),name)!=0)
		{
			arr2[K]=arr[i];
			K++;
		}

	}
	RewriteFilePlane(arr2,K);
}
//------------------------------------------------------------
//------------------------------------------------------------
	   //order write-read from file
//------------------------------------------------------------
//------------------------------------------------------------
 void WriteToFileO(order o)
{
	ofstream f_out;
	f_out.open(FileO,ios::binary|ios::app);
	 if (f_out.is_open())
	 {
	  f_out.write((char*) &o, sizeof(order));
	 }
	f_out.close();
};
int ReadFromFileO(order arr[100])
{
	ifstream f_in;
	int i=0;
	f_in.open(FileO,ios::binary|ios::in);
	 if (f_in.is_open())
	 {
	  order o;
	  while (f_in.read((char*) &o, sizeof(order)))
	  {
		  arr[i]=o;
		  i++;
	  }
	 }
	f_in.close();
	return i;
};
void RewriteFileO(order arr[100], int N)
{
	ofstream f_out;
	f_out.open(FileO, ios::binary|ios::out);
	if (f_out.is_open())
	{
		for (int i = 0; i < N; i++)
		{
			f_out.write((char*) &arr[i], sizeof(order));
		}
	}
	f_out.close();
};
int SortYearCar(car arr[100])
{
int N=ReadFromFileCar(arr);
  int i,j;
  for (i=0; i < N-1; i++)
	for (j=0; j < N-1; j++)
	  if (arr[j].getyear()<arr[j+1].getyear())
	  {
		car tmp;
		tmp=arr[j];
		arr[j]=arr[j+1];
		arr[j+1]=tmp;
	  }
  return N;
}
int SortYearMoto(moto arr[100])
{
int N=ReadFromFileMoto(arr);
  int i,j;
  for (i=0; i < N-1; i++)
	for (j=0; j < N-1; j++)
	  if (arr[j].getyear()<arr[j+1].getyear())
	  {
		moto tmp;
		tmp=arr[j];
		arr[j]=arr[j+1];
		arr[j+1]=tmp;
	  }
  return N;
}
int SortYearPlane(plane arr[100])
{
int N=ReadFromFilePlane(arr);
  int i,j;
  for (i=0; i < N-1; i++)
	for (j=0; j < N-1; j++)
	  if (arr[j].getyear()<arr[j+1].getyear())
	  {
		plane tmp;
		tmp=arr[j];
		arr[j]=arr[j+1];
		arr[j+1]=tmp;
	  }
  return N;
}

int SortYearqaz(car arr[100])
{
  int N=ReadFromFileCar(arr);
  int i,j;
  for (i=0; i > N-1; i++)
	for (j=0; j > N-1; j++)
	  if (arr[j].getyear()<arr[j+1].getyear())
	  {
		car tmp;
		tmp=arr[j];
		arr[j]=arr[j+1];
		arr[j+1]=tmp;
	  }
  return N;
};

int SortYearMotoUp(moto arr[100])
{
  int N=ReadFromFileMoto(arr);
  int i,j;
  for (i=0; i > N-1; i++)
	for (j=0; j > N-1; j++)
	  if (arr[j].getyear()<arr[j+1].getyear())
	  {
		moto tmp;
		tmp=arr[j];
		arr[j]=arr[j+1];
		arr[j+1]=tmp;
	  }
  return N;
};

int SortYearPlaneUp(plane arr[100])
{
  int N=ReadFromFilePlane(arr);
  int i,j;
  for (i=0; i > N-1; i++)
	for (j=0; j > N-1; j++)
	  if (arr[j].getyear()<arr[j+1].getyear())
	  {
		plane tmp;
		tmp=arr[j];
		arr[j]=arr[j+1];
		arr[j+1]=tmp;
	  }
  return N;
};

