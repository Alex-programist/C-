//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit3.h"
#include "Unit5.h"
#include "Unit4.h"
#include "Unit7.h"
#include "Unit1.h"
#include "File1.h"
#include "File1.h"
#include "Project1PCH1.h"
#include "Unit2.h"
#include "Unit6.h"
#include <FileCtrl.hpp>
#include <jpeg.hpp>
#include "Unit8.h"
#include "FileEditor.h"
#include "ABOUT.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm3 *Form3;
int i2=0;
//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm3::Button1Click(TObject *Sender)
{
  Form5->Show();
}
//---------------------------------------------------------------------------
void __fastcall TForm3::ScrollBoxClear()
{
	i2 = 0;
	delete ScrollBox1;
	ScrollBox1 = new TScrollBox(this);
	ScrollBox1->Parent=GroupBox1;
	ScrollBox1->Align = alClient;
	ScrollBox1->Visible=True;
}

void __fastcall TForm3::ButtonClick1(TObject *Sender)
{
	TButton *btn = dynamic_cast<TButton *>(Sender);
	if (btn)
	{
		car arr[100];
		int N=ReadFromFileCar(arr);

		order o;
		o.setobj_buyer(current_user);
		o.setobj_car(arr[btn->Tag]);
		WriteToFileO(o);

		ShowMessage("�������");
	}
}
void __fastcall GeneratePanelsTransport(car c,int q)
{
	TPanel *Panel;
	Panel= new TPanel(Form3);
	Panel->Parent=Form3->ScrollBox1;
	Panel->Top=10 + i2 * 220;
	Panel->Left=10;
	Panel->Height= 200;
	Panel->Width=941;
	Panel->Visible=True;

			TLabel *Label;
			Label = new TLabel(Form3);
			Label->Parent = Panel;
			Label->Top = 5;
			Label->Left = 10;
			Label->Caption =  "����" ;
			Label->Font->Size = 14;

			TImage *Image;
			Image = new TImage(Form3);
			Image->Parent = Panel;
			Image->Top = 35;
			Image->Left = 10;
		  	Image->Picture->LoadFromFile(c.getqaz());
			Image->Stretch = true;

			TLabel *LabelName;
			LabelName = new TLabel(Form3);
			LabelName->Parent = Panel;
			LabelName->Top = 30;
			LabelName->Left = 250;
			LabelName->Caption = "�����: " + AnsiString(c.getname());
			LabelName->Font->Size = 12;

			TLabel *LabelModel;
			LabelModel = new TLabel(Form3);
			LabelModel->Parent = Panel;
			LabelModel->Top = 50;
			LabelModel->Left = 250;
			LabelModel->Caption = "������: " + AnsiString(c.getmodel());
			LabelModel->Font->Size = 12;

			TLabel *LabelYear;
			LabelYear = new TLabel(Form3);
			LabelYear->Parent = Panel;
			LabelYear->Top = 70;
			LabelYear->Left = 250;
			LabelYear->Caption = "г� �������: " + IntToStr(c.getyear());
			LabelYear->Font->Size = 12;

				TLabel *LabelEngine;
			LabelEngine = new TLabel(Form3);
			LabelEngine->Parent = Panel;
			LabelEngine->Top = 90;
			LabelEngine->Left = 250;
			LabelEngine->Caption = "��'�� �������(cm3): " + FloatToStr(c.getengine());
			LabelEngine->Font->Size = 12;

				TLabel *LabelPower;
			LabelEngine = new TLabel(Form3);
			LabelEngine->Parent = Panel;
			LabelEngine->Top = 110;
			LabelEngine->Left = 250;
			LabelEngine->Caption = "����������(�B�): " + FloatToStr(c.getengine());
			LabelEngine->Font->Size = 12;

				TLabel *LabelNumber_seats;
			LabelNumber_seats = new TLabel(Form3);
			LabelNumber_seats->Parent = Panel;
			LabelNumber_seats->Top = 130;
			LabelNumber_seats->Left = 250;
			LabelNumber_seats->Caption = "ʳ������ ���������� ����: " + IntToStr(c.getnumber_of_seats());
			LabelNumber_seats->Font->Size = 12;

				TLabel *LabelColor;
			LabelColor = new TLabel(Form3);
			LabelColor->Parent = Panel;
			LabelColor->Top = 150;
			LabelColor->Left = 250;
			LabelColor->Caption = "����: " + AnsiString(c.getcolor());
			LabelColor->Font->Size = 12;

				TLabel *LabelFuel;
			LabelFuel = new TLabel(Form3);
			LabelFuel->Parent = Panel;
			LabelFuel->Top = 30;
			LabelFuel->Left = 600;
			LabelFuel->Caption = "��� ������: " + AnsiString(c.getkind_of_fuel());
			LabelFuel->Font->Size = 12;

				TLabel *LabelVolume;
			LabelVolume = new TLabel(Form3);
			LabelVolume->Parent = Panel;
			LabelVolume->Top = 50;
			LabelVolume->Left = 600;
			LabelVolume->Caption = "��'�� ����(�): " + FloatToStr(c.gettank_volume());
			LabelVolume->Font->Size = 12;

					TLabel *LabelBody;
			LabelBody = new TLabel(Form3);
			LabelBody->Parent = Panel;
			LabelBody->Top = 70;
			LabelBody->Left = 600;
			LabelBody->Caption = "��� ������: " + AnsiString(c.gettype_of_body());
			LabelBody->Font->Size = 12;

					TLabel *LabelKPP;
			LabelKPP = new TLabel(Form3);
			LabelKPP->Parent = Panel;
			LabelKPP->Top = 90;
			LabelKPP->Left = 600;
			LabelKPP->Caption = "���: " + AnsiString(c.getKPP());
			LabelKPP->Font->Size = 12;

						TLabel *LabelDrive;
			LabelDrive = new TLabel(Form3);
			LabelDrive->Parent = Panel;
			LabelDrive->Top = 110;
			LabelDrive->Left = 600;
			LabelDrive->Caption = "�����: " + AnsiString(c.gettype_of_drive());
			LabelDrive->Font->Size = 12;

				TLabel *LabelDoor;
			LabelDoor = new TLabel(Form3);
			LabelDoor->Parent = Panel;
			LabelDoor->Top = 130;
			LabelDoor->Left = 600;
			LabelDoor->Caption = "ʳ������ ������: " + IntToStr(c.getdoor());
			LabelDoor->Font->Size = 12;

				TLabel *LabelPrice;
			LabelPrice = new TLabel(Form3);
			LabelPrice->Parent = Panel;
			LabelPrice->Top = 150;
			LabelPrice->Left = 600;
			LabelPrice->Caption = "ֳ��($): " + FloatToStr(c.getprice());
			LabelPrice->Font->Size = 12;

			TButton *ButtonPC;
			ButtonPC = new TButton(Form3);
			ButtonPC->Parent = Panel;
			ButtonPC->Top = 150;
			ButtonPC->Left = 800;
			ButtonPC->Height= 40;
			ButtonPC->Width=100;
			ButtonPC->Caption = "�������� ";
			ButtonPC->Font->Size = 12;
			ButtonPC->OnClick = Form3->ButtonClick1;
			ButtonPC->Hint="car";
			ButtonPC->Tag=q;
				i2++;
}

void __fastcall TForm3::ButtonClick(TObject *Sender)
{
	TButton *btn = dynamic_cast<TButton *>(Sender);
	if (btn)
	{
		moto arr[100];
		int N=ReadFromFileMoto(arr);

		order o;
		o.setobj_buyer(current_user);
		o.setmoto(arr[btn->Tag]);

		WriteToFileO(o);

		ShowMessage("�������");
	}
}

void __fastcall TForm3::ButtonClick2(TObject *Sender)
{
	TButton *btn = dynamic_cast<TButton *>(Sender);
	if (btn)
	{
		plane arr[100];
		int N=ReadFromFilePlane(arr);

		order o;
		o.setobj_buyer(current_user);
		o.setplane(arr[btn->Tag]);
		o.setaccepted(false);
		WriteToFileO(o);

		ShowMessage("�������");
	}
}
void __fastcall GeneratePanelsTransport(moto m,int i)
{
	TPanel *Panel;
	Panel= new TPanel(Form3);
	Panel->Parent=Form3->ScrollBox1;
	Panel->Top=10 + i2 * 220;
	Panel->Left=10;
	Panel->Height= 200;
	Panel->Width=941;
	Panel->Visible=True;

			TLabel *Label;
			Label = new TLabel(Form3);
			Label->Parent = Panel;
			Label->Top = 5;
			Label->Left = 10;
			Label->Caption =  "Mo��" ;
			Label->Font->Size = 14;

			TImage *Image;
			Image = new TImage(Form3);
			Image->Parent = Panel;
			Image->Top = 35;
			Image->Left = 10;
			try{
					Image->Picture->LoadFromFile(m.getImg());
			   }
			catch(...){};
			Image->Stretch = true;

			TLabel *LabelName;
			LabelName = new TLabel(Form3);
			LabelName->Parent = Panel;
			LabelName->Top = 30;
			LabelName->Left = 250;
			LabelName->Caption = "�����: " + AnsiString(m.getname());
			LabelName->Font->Size = 12;

			TLabel *LabelModel;
			LabelModel = new TLabel(Form3);
			LabelModel->Parent = Panel;
			LabelModel->Top = 50;
			LabelModel->Left = 250;
			LabelModel->Caption = "������: " + AnsiString(m.getmodel());
			LabelModel->Font->Size = 12;

			TLabel *LabelYear;
			LabelYear = new TLabel(Form3);
			LabelYear->Parent = Panel;
			LabelYear->Top = 70;
			LabelYear->Left = 250;
			LabelYear->Caption = "г� �������: " + IntToStr(m.getyear());
			LabelYear->Font->Size = 12;

				TLabel *LabelEngine;
			LabelEngine = new TLabel(Form3);
			LabelEngine->Parent = Panel;
			LabelEngine->Top = 90;
			LabelEngine->Left = 250;
			LabelEngine->Caption = "��'�� �������(cm3): " + FloatToStr(m.getengine());
			LabelEngine->Font->Size = 12;

				TLabel *LabelPower;
			LabelEngine = new TLabel(Form3);
			LabelEngine->Parent = Panel;
			LabelEngine->Top = 110;
			LabelEngine->Left = 250;
			LabelEngine->Caption = "����������(�B�): " + FloatToStr(m.getpower());
			LabelEngine->Font->Size = 12;

				TLabel *LabelNumber_seats;
			LabelNumber_seats = new TLabel(Form3);
			LabelNumber_seats->Parent = Panel;
			LabelNumber_seats->Top = 130;
			LabelNumber_seats->Left = 250;
			LabelNumber_seats->Caption = "ʳ������ ���������� ����: " + IntToStr(m.getnumber_of_seats());
			LabelNumber_seats->Font->Size = 12;

				TLabel *LabelColor;
			LabelColor = new TLabel(Form3);
			LabelColor->Parent = Panel;
			LabelColor->Top = 150;
			LabelColor->Left = 250;
			LabelColor->Caption = "����: " + AnsiString(m.getcolor());
			LabelColor->Font->Size = 12;

				TLabel *LabelFuel;
			LabelFuel = new TLabel(Form3);
			LabelFuel->Parent = Panel;
			LabelFuel->Top = 30;
			LabelFuel->Left = 600;
			LabelFuel->Caption = "��� ������: " + AnsiString(m.getkind_of_fuel());
			LabelFuel->Font->Size = 12;

				TLabel *LabelVolume;
			LabelVolume = new TLabel(Form3);
			LabelVolume->Parent = Panel;
			LabelVolume->Top = 50;
			LabelVolume->Left = 600;
			LabelVolume->Caption = "��'�� ����(�): " + FloatToStr(m.gettank_volume());
			LabelVolume->Font->Size = 12;

					TLabel *LabelBody;
			LabelBody = new TLabel(Form3);
			LabelBody->Parent = Panel;
			LabelBody->Top = 70;
			LabelBody->Left = 600;
			LabelBody->Caption = "��� ������: " + AnsiString(m.gettype_of_body());
			LabelBody->Font->Size = 12;

			TLabel *LabelPrice;
			LabelPrice = new TLabel(Form3);
			LabelPrice->Parent = Panel;
			LabelPrice->Top = 90;
			LabelPrice->Left = 600;
			LabelPrice->Caption = "ֳ��($): " + FloatToStr(m.getprice());
			LabelPrice->Font->Size = 12;

			TButton *ButtonPPP;
			ButtonPPP = new TButton(Form3);
			ButtonPPP->Parent = Panel;
			ButtonPPP->Top = 150;
			ButtonPPP->Left = 800;
			ButtonPPP->Height= 40;
			ButtonPPP->Width=100;
			ButtonPPP->Caption = "�������� ";
			ButtonPPP->Font->Size = 12;
			ButtonPPP->OnClick = Form3->ButtonClick;
			ButtonPPP->Hint="moto";
			ButtonPPP->Tag=i;
			i2++;
}

void __fastcall GeneratePanelsTransport(plane p,int i)
{
	TPanel *Panel;
	Panel= new TPanel(Form3);
	Panel->Parent=Form3->ScrollBox1;
	Panel->Top=10 + i2 * 220;
	Panel->Left=10;
	Panel->Height= 200;
	Panel->Width=941;
	Panel->Visible=True;

			TLabel *Label;
			Label = new TLabel(Form3);
			Label->Parent = Panel;
			Label->Top = 5;
			Label->Left = 10;
			Label->Caption =  "˳���" ;
			Label->Font->Size = 14;

			TImage *Image;
			Image = new TImage(Form3);
			Image->Parent = Panel;
			Image->Top = 35;
			Image->Left = 10;
			try{
					Image->Picture->LoadFromFile(p.getqwe());
			   }
			catch(...){};
			Image->Stretch = true;

			TLabel *LabelName;
			LabelName = new TLabel(Form3);
			LabelName->Parent = Panel;
			LabelName->Top = 30;
			LabelName->Left = 250;
			LabelName->Caption = "�����: " + AnsiString(p.getname());
			LabelName->Font->Size = 12;

			TLabel *LabelModel;
			LabelModel = new TLabel(Form3);
			LabelModel->Parent = Panel;
			LabelModel->Top = 50;
			LabelModel->Left = 250;
			LabelModel->Caption = "������: " + AnsiString(p.getmodel());
			LabelModel->Font->Size = 12;

			TLabel *LabelYear;
			LabelYear = new TLabel(Form3);
			LabelYear->Parent = Panel;
			LabelYear->Top = 70;
			LabelYear->Left = 250;
			LabelYear->Caption = "г� �������: " + IntToStr(p.getyear());
			LabelYear->Font->Size = 12;

				TLabel *LabelEngine;
			LabelEngine = new TLabel(Form3);
			LabelEngine->Parent = Panel;
			LabelEngine->Top = 90;
			LabelEngine->Left = 250;
			LabelEngine->Caption = "��'�� �������(cm3): " + FloatToStr(p.getengine());
			LabelEngine->Font->Size = 12;

				TLabel *LabelPower;
			LabelEngine = new TLabel(Form3);
			LabelEngine->Parent = Panel;
			LabelEngine->Top = 110;
			LabelEngine->Left = 250;
			LabelEngine->Caption = "����������(�B�): " + FloatToStr(p.getpower());
			LabelEngine->Font->Size = 12;

				TLabel *LabelNumber_seats;
			LabelNumber_seats = new TLabel(Form3);
			LabelNumber_seats->Parent = Panel;
			LabelNumber_seats->Top = 130;
			LabelNumber_seats->Left = 250;
			LabelNumber_seats->Caption = "ʳ������ ���������� ����: " + IntToStr(p.getnumber_of_seats());
			LabelNumber_seats->Font->Size = 12;

				TLabel *LabelColor;
			LabelColor = new TLabel(Form3);
			LabelColor->Parent = Panel;
			LabelColor->Top = 150;
			LabelColor->Left = 250;
			LabelColor->Caption = "����: " + AnsiString(p.getcolor());
			LabelColor->Font->Size = 12;

				TLabel *LabelFuel;
			LabelFuel = new TLabel(Form3);
			LabelFuel->Parent = Panel;
			LabelFuel->Top = 30;
			LabelFuel->Left = 600;
			LabelFuel->Caption = "��� ������: " + AnsiString(p.getkind_of_fuel());
			LabelFuel->Font->Size = 12;

				TLabel *LabelVolume;
			LabelVolume = new TLabel(Form3);
			LabelVolume->Parent = Panel;
			LabelVolume->Top = 50;
			LabelVolume->Left = 600;
			LabelVolume->Caption = "��'�� ����(�): " + FloatToStr(p.gettank_volume());
			LabelVolume->Font->Size = 12;

					TLabel *LabelNumber_door;
			LabelNumber_door = new TLabel(Form3);
			LabelNumber_door->Parent = Panel;
			LabelNumber_door->Top = 70;
			LabelNumber_door->Left = 600;
			LabelNumber_door->Caption = "ʳ������ ������: " + AnsiString(p.getnumber_door());
			LabelNumber_door->Font->Size = 12;

				TLabel *LabelNumber_window;
			LabelNumber_window = new TLabel(Form3);
			LabelNumber_window->Parent = Panel;
			LabelNumber_window->Top = 90;
			LabelNumber_window->Left = 600;
			LabelNumber_window->Caption = "ʳ������ ����: " + AnsiString(p.getnumber_window());
			LabelNumber_window->Font->Size = 12;

			TLabel *LabelPrice;
			LabelPrice = new TLabel(Form3);
			LabelPrice->Parent = Panel;
			LabelPrice->Top = 110;
			LabelPrice->Left = 600;
			LabelPrice->Caption = "ֳ��($): " + FloatToStr(p.getprice());
			LabelPrice->Font->Size = 12;

			TButton *ButtonPlane;
			ButtonPlane = new TButton(Form3);
			ButtonPlane->Parent = Panel;
			ButtonPlane->Top = 150;
			ButtonPlane->Left = 800;
			ButtonPlane->Height= 40;
			ButtonPlane->Width=100;
			ButtonPlane->Caption = "�������� ";
			ButtonPlane->Font->Size = 12;
			ButtonPlane->OnClick = Form3->ButtonClick2;
			ButtonPlane->Hint="plane";
			ButtonPlane->Tag=i;
			i2++;
}
void __fastcall TForm3::Button2Click(TObject *Sender)
{
Form4->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm3::Button3Click(TObject *Sender)
{
Form7->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm3::FormClose(TObject *Sender, TCloseAction &Action)
{
Form1->Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N11Click(TObject *Sender)
{
	ScrollBoxClear();
	i2 = 0;

	car arr[100];

	int NM = ReadFromFileCar(arr);
	for (int i = 0; i < NM; i++)
	{
		GeneratePanelsTransport(arr[i],i);
	}
    	moto ar[100];

	int NC = ReadFromFileMoto(ar);
	for (int i = 0; i < NC; i++)
	{
		GeneratePanelsTransport(ar[i],i);
	}
		plane a[100];

	int NP = ReadFromFilePlane(a);
	for (int i = 0; i < NP; i++)
	{
		GeneratePanelsTransport(a[i],i);
	}

}
//---------------------------------------------------------------------------

void __fastcall TForm3::FormShow(TObject *Sender)
{
for (int i = 0; i < StatusBar1->Panels->Count; i++)
{
 StatusBar1->Panels->Items[0]->Text=Form1->Edit1->Text;
}
	ScrollBoxClear();
	i2 = 0;

	car arr[100];

	int NM = ReadFromFileCar(arr);
	for (int i = 0; i < NM; i++)
	{
		GeneratePanelsTransport(arr[i],i);
	}
	moto ar[100];

	int NC = ReadFromFileMoto(ar);
	for (int i = 0; i < NC; i++)
	{
		GeneratePanelsTransport(ar[i],i);
	}
		plane a[100];

	int NP = ReadFromFilePlane(a);
	for (int i = 0; i < NP; i++)
	{
		GeneratePanelsTransport(a[i],i);
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N15Click(TObject *Sender)
{
ScrollBoxClear();
	i2 = 0;

	int find = StrToInt(InputBox(L"������ �� �������!", L"г�:", L""));

	car arr[100];
	int NM = ReadFromFileCar(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getyear() == find)
		GeneratePanelsTransport(arr[i],i);
	}
}
//---------------------------------------------------------------------------


void __fastcall TForm3::N20Click(TObject *Sender)
{
	Form8->Show();
}
//---------------------------------------------------------------------------
void __fastcall TForm3::FormCreate(TObject *Sender)
{
for( int i=0; i<2; i++ )
	{
	StatusBar1->Panels->Add();
	StatusBar1->Panels->Items[i]->Width = StatusBar1->Parent->Width/3;
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm3::FormKeyUp(TObject *Sender, WORD &Key, TShiftState Shift)
{
switch (Key)
	{
	case VK_CAPITAL:
		StatusBar1->Panels->Items[1]->Text = (::GetKeyState(VK_CAPITAL)) ? "CapsLock" : "";
		break;
	case VK_NUMLOCK:
		StatusBar1->Panels->Items[2]->Text = (::GetKeyState(VK_NUMLOCK)) ? "NumLock" : "";
		break;
}
}
//---------------------------------------------------------------------------

void __fastcall TForm3::C1Click(TObject *Sender)
{
Form3->Hide();
Form5->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N23Click(TObject *Sender)
{
Form1->Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N21Click(TObject *Sender)
{
Form3->Hide();
Form1->Show();
}
//---------------------------------------------------------------------------




void __fastcall TForm3::N8Click(TObject *Sender)
{
Form3->Hide();
Form7->Show();
Form7->Timer1->Enabled=true;
Form7->StringGrid2->Visible=false;
Form7->StringGrid1->Visible=true;
Form7->StringGrid3->Visible=false;
Form7->Image5->Visible=false;
Form7->Image6->Visible=false;
Form7->Image3->Visible=false;
Form7->Image2->Visible=true;
Form7->Image4->Visible=true;
Form7->Image7->Visible=true;
Form7->Image8->Visible=false;
Form7->Image9->Visible=false;
Form7->Image10->Visible=false;
Form7->StringGrid1->Visible=true;
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N7Click(TObject *Sender)
{
Form3->Hide();
Form7->Show();
Form7->Timer2->Enabled=true;
Form7->StringGrid2->Visible=true;
Form7->StringGrid1->Visible=false;
Form7->StringGrid3->Visible=false;
Form7->Image5->Visible=true;
Form7->Image6->Visible=true;
Form7->Image3->Visible=true;
Form7->Image2->Visible=false;
Form7->Image4->Visible=false;
Form7->Image7->Visible=false;
Form7->Image8->Visible=false;
Form7->Image9->Visible=false;
Form7->Image10->Visible=false;
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N10Click(TObject *Sender)
{
Form3->Hide();
Form8->Show();
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N9Click(TObject *Sender)
{
Form3->Hide();
Form7->Show();
Form7->Timer3->Enabled=true;
Form7->StringGrid3->Visible=true;
Form7->StringGrid2->Visible=false;
Form7->StringGrid1->Visible=false;
Form7->Image2->Visible=false;
Form7->Image4->Visible=false;
Form7->Image7->Visible=false;
Form7->Image3->Visible=false;
Form7->Image5->Visible=false;
Form7->Image6->Visible=false;
Form7->StringGrid1->Visible=true;
Form7->Image8->Visible=true;
Form7->Image9->Visible=true;
Form7->Image10->Visible=true;

}
//---------------------------------------------------------------------------

void __fastcall TForm3::N26Click(TObject *Sender)
{
	ScrollBoxClear();
	i2 = 0;

	car arr[100];

	int NM = ReadFromFileCar(arr);
	for (int i = 0; i < NM; i++)
	{
		GeneratePanelsTransport(arr[i],i);
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N27Click(TObject *Sender)
{
ScrollBoxClear();
	i2 = 0;
   	moto ar[100];

	int NC = ReadFromFileMoto(ar);
	for (int i = 0; i < NC; i++)
	{
		GeneratePanelsTransport(ar[i],i);
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N28Click(TObject *Sender)
{
ScrollBoxClear();
	i2 = 0;
		plane a[100];

	int NP = ReadFromFilePlane(a);
	for (int i = 0; i < NP; i++)
	{
		GeneratePanelsTransport(a[i],i);
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N13Click(TObject *Sender)
{
	ScrollBoxClear();
	i2 = 0;

	AnsiString find = (InputBox(L"������ ����� ����!", L"����� ����:", L""));

	car arr[100];
	int NM = ReadFromFileCar(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getname() == find)
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------

void __fastcall TForm3::N14Click(TObject *Sender)
{

	ScrollBoxClear();
	i2 = 0;

	AnsiString find = (InputBox(L"������ ������ ����!", L"������:", L""));

	car arr[100];
	int NM = ReadFromFileCar(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getmodel() == find)
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------

void __fastcall TForm3::N16Click(TObject *Sender)
{
  ScrollBoxClear();
	i2 = 0;

	int find = StrToInt(InputBox(L"������ ������� ���������� ����!", L"ʳ������ ���������� ����:", L""));

	car arr[100];
	int NM = ReadFromFileCar(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getnumber_of_seats() == find)
		GeneratePanelsTransport(arr[i],i);
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N17Click(TObject *Sender)
{
	ScrollBoxClear();
	i2 = 0;

	AnsiString find = (InputBox(L"������ ��� ������!", L"��� ������:", L""));

	car arr[100];
	int NM = ReadFromFileCar(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].gettype_of_body() == find)
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------

void __fastcall TForm3::N18Click(TObject *Sender)
{
	ScrollBoxClear();
	i2 = 0;

	AnsiString find = (InputBox(L"������ ��� �������!", L"��� �������:", L""));

	car arr[100];
	int NM = ReadFromFileCar(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].gettype_of_drive() == find)
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------


void __fastcall TForm3::N19Click(TObject *Sender)
{
	ScrollBoxClear();
	i2 = 0;

	AnsiString find = (InputBox(L"������ ��� ������!", L"��� ������:", L""));

	car arr[100];
	int NM = ReadFromFileCar(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getkind_of_fuel() == find)
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------


void __fastcall TForm3::N29Click(TObject *Sender)
{
   	ScrollBoxClear();
	i2 = 0;

	AnsiString find = (InputBox(L"������ ��� ���!", L"��� ���:", L""));

	car arr[100];
	int NM = ReadFromFileCar(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getKPP() == find)
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------

void __fastcall TForm3::N31Click(TObject *Sender)
{
	ScrollBoxClear();
	i2 = 0;

	AnsiString find = (InputBox(L"������ ����� ����!", L"����� ����:", L""));

	moto arr[100];
	int NM = ReadFromFileMoto(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getname() == find)
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------

void __fastcall TForm3::N32Click(TObject *Sender)
{

	ScrollBoxClear();
	i2 = 0;

	AnsiString find = (InputBox(L"������ ������ ����!", L"������:", L""));

	moto arr[100];
	int NM = ReadFromFileMoto(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getmodel() == find)
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------
void __fastcall TForm3::N33Click(TObject *Sender)
{
 ScrollBoxClear();
	i2 = 0;

	int find = StrToInt(InputBox(L"������ �� �������!", L"г�:", L""));

	moto arr[100];
	int NM = ReadFromFileMoto(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getyear() == find)
		GeneratePanelsTransport(arr[i],i);
	}
}

//---------------------------------------------------------------------------

void __fastcall TForm3::N34Click(TObject *Sender)
{
   ScrollBoxClear();
	i2 = 0;

	int find = StrToInt(InputBox(L"������ ������� ���������� ����!", L"ʳ������ ���������� ����:", L""));

	moto arr[100];
	int NM = ReadFromFileMoto(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getnumber_of_seats() == find)
		GeneratePanelsTransport(arr[i],i);
	}
}

//---------------------------------------------------------------------------
void __fastcall TForm3::N35Click(TObject *Sender)
{
 	ScrollBoxClear();
	i2 = 0;

	AnsiString find = (InputBox(L"������ ��� ������!", L"��� ������:", L""));

	moto arr[100];
	int NM = ReadFromFileMoto(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].gettype_of_body() == find)
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------

void __fastcall TForm3::N37Click(TObject *Sender)
{
   	ScrollBoxClear();
	i2 = 0;

	AnsiString find = (InputBox(L"������ ����� �����!", L"����� �����:", L""));

	plane arr[100];
	int NM = ReadFromFilePlane(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getname() == find)
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------

void __fastcall TForm3::N38Click(TObject *Sender)
{

	ScrollBoxClear();
	i2 = 0;

	AnsiString find = (InputBox(L"������ ������ �����!", L"������ �����:", L""));

	plane arr[100];
	int NM = ReadFromFilePlane(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getmodel() == find)
			GeneratePanelsTransport(arr[i],i);
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N39Click(TObject *Sender)
{
    ScrollBoxClear();
	i2 = 0;

	int find = StrToInt(InputBox(L"������ �� �������!", L"г�:", L""));

	plane arr[100];
	int NM = ReadFromFilePlane(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getyear() == find)
		GeneratePanelsTransport(arr[i],i);
	}
}
//---------------------------------------------------------------------------

void __fastcall TForm3::N40Click(TObject *Sender)
{
     ScrollBoxClear();
	i2 = 0;

	int find = StrToInt(InputBox(L"������ ������� ���������� ����!", L"ʳ������ ���������� ����:", L""));

	plane arr[100];
	int NM = ReadFromFilePlane(arr);
	for (int i = 0; i < NM; i++)
	{
		if(arr[i].getnumber_of_seats() == find)
		GeneratePanelsTransport(arr[i],i);
	}
}

//---------------------------------------------------------------------------


void __fastcall TForm3::N42Click(TObject *Sender)
{
	ScrollBoxClear();
	int i2 = 0;

			car arr[100];
		   int NM = SortYearCar(arr);
		   for (int i = 0; i < NM; i++)
	{
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------

void __fastcall TForm3::N43Click(TObject *Sender)
{
	ScrollBoxClear();
	int i2 = 0;

			car arr[100];
		   int NM = SortYearqaz(arr);
		   for (int i = 0; i < NM; i++)
	{
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------

void __fastcall TForm3::N45Click(TObject *Sender)
{
  	ScrollBoxClear();
	int i2 = 0;

			moto arr[100];
		   int NM = SortYearMoto(arr);
		   for (int i = 0; i < NM; i++)
	{
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------

void __fastcall TForm3::N46Click(TObject *Sender)
{
	ScrollBoxClear();
	int i2 = 0;

			moto arr[100];
		   int NM = SortYearMotoUp(arr);
		   for (int i = 0; i < NM; i++)
	{
			GeneratePanelsTransport(arr[i],i);
	}

}
//---------------------------------------------------------------------------


void __fastcall TForm3::N24Click(TObject *Sender)
{
Form6->Show();
}
//---------------------------------------------------------------------------


void __fastcall TForm3::N25Click(TObject *Sender)
{
AboutBox->ShowModal();
}
//---------------------------------------------------------------------------

